"""
Tests for AI Client package.
"""

import os
import sys
from pathlib import Path
import pytest
from typing import List
from pydantic import BaseModel, Field, ValidationError

# Add src to Python path for imports
project_root = Path(__file__).parent.parent
src_path = project_root / "src"
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))

# Import the AI client components
from ai_client import (
    AiClient,
    TextGenerator,
    StructuredGenerator,
    GenerationConfig,
    StructuredResponseConfig
)
from ai_client.models import ConversationContext


class BookRecommendationModel(BaseModel):
    """Test model for book recommendations."""
    title: str = Field(description="The title of the book")
    author: str = Field(description="The author of the book")
    genre: str = Field(description="The genre of the book")
    rating: float = Field(description="Rating out of 5.0", ge=0.0, le=5.0)
    summary: str = Field(description="Brief summary of the book")


class PersonProfileModel(BaseModel):
    """Test model for person profiles."""
    name: str = Field(description="Full name")
    title: str = Field(description="Job title")
    skills: List[str] = Field(description="List of key skills")
    experience_years: int = Field(description="Years of experience")


# Unit Tests (No API calls)
class TestAiClientCreation:
    """Test AI client creation and validation."""

    @pytest.mark.unit
    def test_client_creation_default(self):
        """Test creating client with default settings."""
        client = AiClient(api_key="test-key")
        assert client.config.model == "openai/gpt-4.1"
        assert client.config.temperature == 0.7
        assert client.system_prompt is None

    @pytest.mark.unit
    def test_client_creation_with_model(self):
        """Test creating client with specific model."""
        client = AiClient(model="anthropic/claude-3-5-sonnet", api_key="test-key")
        assert client.config.model == "anthropic/claude-3-5-sonnet"

    @pytest.mark.unit
    def test_client_creation_with_system_prompt(self):
        """Test creating client with system prompt."""
        prompt = "You are a helpful assistant."
        client = AiClient(system_prompt=prompt, api_key="test-key")
        assert client.system_prompt == prompt

    @pytest.mark.unit
    def test_client_creation_with_config(self):
        """Test creating client with custom config."""
        config = GenerationConfig(
            model="openai/gpt-4.1",
            temperature=0.5,
            max_tokens=100
        )
        client = AiClient(config=config, api_key="test-key")
        assert client.config.temperature == 0.5
        assert client.config.max_tokens == 100

    @pytest.mark.unit
    def test_model_validation_valid_models(self):
        """Test valid model formats."""
        valid_models = [
            "openai/gpt-4.1",
            "anthropic/claude-3-5-sonnet",
            "google/gemini-pro",
            "auto",
            "AUTO"
        ]
        
        for model in valid_models:
            client = AiClient(model=model, api_key="test-key")
            assert client.config.model == model

    @pytest.mark.unit
    def test_model_validation_invalid_models(self):
        """Test invalid model formats raise errors."""
        invalid_models = [
            "gpt-4",          # Missing provider
            "openai/",        # Missing model name
            "/gpt-4",         # Missing provider
            "",               # Empty
            "invalid-format", # No slash
        ]
        
        for model in invalid_models:
            with pytest.raises(ValueError):
                AiClient(model=model, api_key="test-key")

    @pytest.mark.unit
    def test_generation_config_creation(self):
        """Test GenerationConfig creation."""
        config = GenerationConfig(
            model="openai/gpt-4.1",
            temperature=0.7,
            max_tokens=150,
            top_p=0.9
        )
        assert config.model == "openai/gpt-4.1"
        assert config.temperature == 0.7
        assert config.max_tokens == 150
        assert config.top_p == 0.9

    @pytest.mark.unit
    def test_structured_response_config(self):
        """Test StructuredResponseConfig creation."""
        config = StructuredResponseConfig(
            strict=True,
            max_retries=3,
            retry_delay=2.0
        )
        assert config.strict is True
        assert config.max_retries == 3
        assert config.retry_delay == 2.0

    @pytest.mark.unit
    def test_conversation_context(self):
        """Test ConversationContext functionality."""
        context = ConversationContext()
        
        # Test adding messages
        context.add_message("user", "Hello")
        context.add_message("assistant", "Hi there!")
        
        assert len(context.messages) == 2
        assert context.messages[0].role == "user"
        assert context.messages[0].content == "Hello"
        assert context.messages[1].role == "assistant"
        assert context.messages[1].content == "Hi there!"

    @pytest.mark.unit
    def test_text_generator_creation(self):
        """Test TextGenerator creation."""
        client = AiClient(api_key="test-key")
        generator = TextGenerator(client=client)
        assert generator.client == client

    @pytest.mark.unit
    def test_structured_generator_creation(self):
        """Test StructuredGenerator creation."""
        client = AiClient(api_key="test-key")
        config = StructuredResponseConfig(strict=True)
        generator = StructuredGenerator(client=client, structured_config=config)
        assert generator.client == client
        assert generator.structured_config.strict is True


# AI Tests (Require API key)
@pytest.mark.ai
class TestAiClientGeneration:
    """Test AI client text generation (requires API key)."""

    def setup_method(self):
        """Set up test client."""
        # Skip if no API key
        if not os.getenv("OPENROUTER_API_KEY"):
            pytest.skip("No OpenRouter API key found")
            
        self.client = AiClient(
            model="openai/gpt-4.1",
            system_prompt="You are a helpful test assistant."
        )

    @pytest.mark.ai
    def test_simple_text_generation(self):
        """Test basic text generation."""
        messages = [{"role": "user", "content": "Say 'Hello, World!' exactly."}]
        response = self.client.generate_text(messages)
        
        assert isinstance(response, str)
        assert len(response) > 0
        assert "Hello" in response

    @pytest.mark.ai
    def test_text_generation_with_config(self):
        """Test text generation with custom config."""
        config = GenerationConfig(
            model="openai/gpt-4.1",
            temperature=0.1,  # Very deterministic
            max_tokens=50
        )
        client = AiClient(config=config)
        
        messages = [{"role": "user", "content": "Count from 1 to 3."}]
        response = client.generate_text(messages)
        
        assert isinstance(response, str)
        assert len(response) <= 200  # Should be short due to max_tokens

    @pytest.mark.ai
    def test_text_generator_simple(self):
        """Test TextGenerator simple generation."""
        generator = TextGenerator(client=self.client)
        response = generator.generate("What is 2+2?")
        
        assert isinstance(response, str)
        assert len(response) > 0

    @pytest.mark.ai
    def test_text_generator_chat(self):
        """Test TextGenerator chat functionality."""
        generator = TextGenerator(client=self.client)
        context = ConversationContext()
        
        # First message
        response1, new_context = generator.chat("Hello!", context=context)
        assert isinstance(response1, str)
        assert len(new_context.messages) == 2  # user + assistant
        
        # Second message in same context
        response2, final_context = generator.chat("What's your name?", context=new_context)
        assert isinstance(response2, str)
        assert len(final_context.messages) == 4  # 2 previous + user + assistant

    @pytest.mark.ai
    def test_structured_generation_simple(self):
        """Test structured generation with simple model."""
        generator = StructuredGenerator(client=self.client)
        
        response = generator.generate_structured(
            prompt="Recommend a science fiction book.",
            response_model=BookRecommendationModel
        )
        
        assert isinstance(response, BookRecommendationModel)
        assert isinstance(response.title, str)
        assert isinstance(response.author, str)
        assert isinstance(response.rating, float)
        assert 0.0 <= response.rating <= 5.0

    @pytest.mark.ai
    def test_structured_generation_with_lists(self):
        """Test structured generation with list fields."""
        generator = StructuredGenerator(client=self.client)
        
        response = generator.generate_structured(
            prompt="Create a profile for a software engineer with 5 years experience.",
            response_model=PersonProfileModel
        )
        
        assert isinstance(response, PersonProfileModel)
        assert isinstance(response.name, str)
        assert isinstance(response.skills, list)
        assert len(response.skills) > 0
        assert isinstance(response.experience_years, int)

    @pytest.mark.ai
    def test_data_extraction(self):
        """Test extracting structured data from unstructured text."""
        generator = StructuredGenerator(client=self.client)
        
        text = """
        John Smith is a Senior Software Engineer at TechCorp.
        He has 8 years of experience and specializes in Python,
        JavaScript, and cloud computing.
        """
        
        profile = generator.extract_data(
            text=text,
            response_model=PersonProfileModel
        )
        
        assert isinstance(profile, PersonProfileModel)
        assert "John Smith" in profile.name
        assert profile.experience_years > 0
        assert len(profile.skills) > 0

    @pytest.mark.ai
    def test_structured_generation_with_retries(self):
        """Test structured generation with retry configuration."""
        config = StructuredResponseConfig(
            strict=True,
            max_retries=2,
            retry_delay=1.0
        )
        generator = StructuredGenerator(
            client=self.client,
            structured_config=config
        )
        
        response = generator.generate_structured(
            prompt="What is the capital of France? Answer with book recommendation format.",
            response_model=BookRecommendationModel
        )
        
        # Should work even with an odd prompt due to retries
        assert isinstance(response, BookRecommendationModel)

    @pytest.mark.ai
    def test_system_prompt_injection(self):
        """Test system prompt injection in structured generation."""
        generator = StructuredGenerator(client=self.client)
        
        response = generator.generate_structured(
            prompt="Recommend a mystery book.",
            response_model=BookRecommendationModel,
            system_prompt="You are a mystery book expert who only recommends Agatha Christie novels."
        )
        
        assert isinstance(response, BookRecommendationModel)
        assert "mystery" in response.genre.lower() or "Mystery" in response.genre

    @pytest.mark.ai
    @pytest.mark.slow
    def test_long_conversation_context(self):
        """Test maintaining context over multiple exchanges."""
        generator = TextGenerator(client=self.client)
        context = ConversationContext()
        
        # Start conversation
        response1, context = generator.chat("My name is Alice.", context=context)
        
        # Continue conversation - should remember name
        response2, context = generator.chat("What's my name?", context=context)
        
        assert isinstance(response2, str)
        assert "Alice" in response2

    @pytest.mark.ai
    def test_error_handling_invalid_model_call(self):
        """Test error handling for API errors."""
        # Create client with invalid model for testing error handling
        invalid_client = AiClient(model="openai/nonexistent-model")
        
        with pytest.raises(Exception):  # Should raise some kind of API error
            invalid_client.generate_text([{"role": "user", "content": "Hello"}])


# Edge cases and error handling
@pytest.mark.unit
class TestErrorHandling:
    """Test error handling and edge cases."""

    @pytest.mark.unit
    def test_empty_messages_list(self):
        """Test behavior with empty messages list."""
        client = AiClient(api_key="test-key")
        
        # This should not crash, but behavior depends on implementation
        try:
            response = client.generate_text([])
            assert isinstance(response, str)
        except Exception:
            # It's okay if this raises an exception
            pass

    @pytest.mark.unit
    def test_invalid_message_format(self):
        """Test behavior with invalid message format."""
        client = AiClient(api_key="test-key")
        
        # This test should not make API calls - checking parameter validation
        # The client should validate message format before API call
        with pytest.raises((ValueError, KeyError, TypeError, Exception)):
            # This might raise different exceptions depending on implementation
            client.generate_text([{"invalid": "format"}])

    @pytest.mark.unit
    def test_pydantic_model_validation(self):
        """Test Pydantic model validation errors."""
        # Test invalid rating (outside 0-5 range)
        with pytest.raises(ValidationError):
            BookRecommendationModel(
                title="Test",
                author="Test Author", 
                genre="Fiction",
                rating=6.0,  # Invalid - over 5.0
                summary="Test summary"
            )

    @pytest.mark.unit
    def test_conversation_context_edge_cases(self):
        """Test ConversationContext edge cases."""
        context = ConversationContext()
        
        # Test getting messages from empty context
        assert len(context.messages) == 0
        
        # Test adding empty messages
        context.add_message("user", "")
        context.add_message("assistant", "")
        assert len(context.messages) == 2