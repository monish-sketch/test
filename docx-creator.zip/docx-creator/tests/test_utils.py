#!/usr/bin/env python3
"""
Testing utilities for DOCX Creator.
"""

import os
import zipfile
from pathlib import Path
import pytest


def check_docx_for_footnotes(docx_path: str) -> bool:
    """
    Check if a DOCX file contains true footnotes by checking for footnotes.xml

    Args:
        docx_path: Path to the DOCX file to test

    Returns:
        bool: True if footnotes.xml exists, False otherwise
    """
    if not os.path.exists(docx_path):
        return False

    try:
        with zipfile.ZipFile(docx_path, 'r') as docx_zip:
            file_list = docx_zip.namelist()
            footnotes_files = [f for f in file_list if 'footnote' in f.lower()]
            return bool(footnotes_files)

    except (zipfile.BadZipFile, Exception):
        return False


def check_multiple_files(file_paths: list) -> dict:
    """Check multiple DOCX files for footnotes and return results"""
    results = {}

    for file_path in file_paths:
        has_footnotes = check_docx_for_footnotes(file_path)
        results[file_path] = has_footnotes

    return results


@pytest.mark.unit
def test_docx_for_footnotes_with_valid_file(tmp_path):
    """Test footnote detection with a valid DOCX file"""
    # Create a mock DOCX file with footnotes
    docx_path = tmp_path / "test_with_footnotes.docx"
    
    # Create a minimal zip structure that mimics a DOCX with footnotes
    with zipfile.ZipFile(docx_path, 'w') as docx_zip:
        docx_zip.writestr('word/document.xml', '<document/>')
        docx_zip.writestr('word/footnotes.xml', '<footnotes/>')
    
    result = check_docx_for_footnotes(str(docx_path))
    assert result is True


@pytest.mark.unit
def test_docx_for_footnotes_without_footnotes(tmp_path):
    """Test footnote detection with a DOCX file without footnotes"""
    docx_path = tmp_path / "test_without_footnotes.docx"
    
    # Create a minimal zip structure without footnotes
    with zipfile.ZipFile(docx_path, 'w') as docx_zip:
        docx_zip.writestr('word/document.xml', '<document/>')
    
    result = check_docx_for_footnotes(str(docx_path))
    assert result is False


@pytest.mark.unit
def test_docx_for_footnotes_nonexistent_file():
    """Test footnote detection with nonexistent file"""
    result = check_docx_for_footnotes('/nonexistent/file.docx')
    assert result is False


@pytest.mark.unit
def test_multiple_files_functionality(tmp_path):
    """Test multiple file checking functionality"""
    # Create test files
    file1 = tmp_path / "with_footnotes.docx"
    file2 = tmp_path / "without_footnotes.docx"
    
    with zipfile.ZipFile(file1, 'w') as zip1:
        zip1.writestr('word/document.xml', '<document/>')
        zip1.writestr('word/footnotes.xml', '<footnotes/>')
    
    with zipfile.ZipFile(file2, 'w') as zip2:
        zip2.writestr('word/document.xml', '<document/>')
    
    file_paths = [str(file1), str(file2)]
    results = check_multiple_files(file_paths)
    
    assert results[str(file1)] is True
    assert results[str(file2)] is False
