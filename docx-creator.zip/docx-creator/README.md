# DOCX Creator

A powerful Python tool for creating professional Word documents with native footnotes, structured financial data, and comprehensive document analysis capabilities.

## 🚀 Features

- **🏗️ Modular Architecture**: Clean separation of concerns with dedicated modules
- **📝 Native Word Footnotes**: True Word footnotes with template-matched formatting
- **📊 Document Analysis**: Comprehensive DOCX structure and formatting analysis
- **🎯 Template Matching**: Extract and replicate formatting from existing documents
- **💼 Financial Report Templates**: Pre-built templates for investment records, capital tables, and financials
- **🔧 Type-Safe Models**: Uses Pydantic for structured data validation
- **🎨 Professional Styling**: Support for custom fonts, colors, borders, and layout
- **📋 CLI Interface**: Comprehensive command-line interface with docopt
- **🧪 Testing Utilities**: Built-in footnote validation and testing tools

## 📁 Project Structure

```
docx-creator/
├── src/
│   ├── dataclass/
│   │   └── final_report/               # Pydantic models for document generation
│   │       ├── __init__.py
│   │       ├── report.py               # Main FinancialReport model
│   │       ├── footnote.py             # Footnote models
│   │       ├── investment.py           # Investment record models
│   │       ├── capital_table.py        # Capital table models
│   │       ├── funding.py              # Funding details models
│   │       └── financials.py           # Financial data models
│   └── docx_creator/
│       ├── __init__.py
│       ├── footnote_manager.py          # Native Word footnote handling
│       ├── financial_report_generator.py # Document generation
│       ├── test_utils.py                # Testing utilities
│       └── analyzer/                    # Document analysis
│           ├── __init__.py
│           └── document_analyzer.py
├── generated_docs/                     # Output documents
├── cli.py                             # Command-line interface
├── pyproject.toml                     # Poetry configuration
├── poetry.lock                        # Locked dependencies
└── README.md
```

## 🛠️ Installation

This project uses Poetry for dependency management:

```bash
# Install Poetry (if not already installed)
curl -sSL https://install.python-poetry.org | python3 -
# OR: python -m pip install poetry

# Clone the repository
git clone <repository-url>
cd docx-creator

# Install project dependencies
poetry install

# Activate the virtual environment
poetry shell
```

## 💻 Usage

### Command Line Interface

The project provides a comprehensive CLI with two main commands:

#### 📄 Generate Financial Reports

```bash
# Generate a basic financial report
poetry run docx-creator generate --output="reports/acme_report.docx" --company="ACME Corp"

# Generate with different data templates
poetry run docx-creator generate --output="report.docx" --template=detailed --verbose

# Generate and test for native footnotes
poetry run docx-creator generate --output="report.docx" --test-footnotes --verbose
```

#### 🔍 Analyze DOCX Documents

```bash
# Analyze document structure and formatting
poetry run docx-creator analyze --file="template.docx" --verbose

# Export formatting template for replication
poetry run docx-creator analyze --file="template.docx" --export-template

# Quick footnote check
poetry run docx-creator analyze --file="document.docx"
```

### CLI Commands

| Command | Description | Required Options |
|---------|-------------|------------------|
| **`generate`** | Create a financial report document | `--output=PATH` |
| **`analyze`** | Analyze DOCX structure and formatting | `--file=PATH` |

### CLI Options

| Option | Description | Default |
|--------|-------------|---------|
| `--output=PATH` | Output file path (required for generate) | - |
| `--file=PATH` | Input DOCX file path (required for analyze) | - |
| `--company=NAME` | Company name for the report | `HAPPI PLANET` |
| `--template=TYPE` | Data template: `basic`, `detailed`, `custom` | `basic` |
| `--test-footnotes` | Test generated document for proper footnotes | `false` |
| `--export-template` | Export formatting template from analyzed document | `false` |
| `--verbose` | Enable verbose output | `false` |
| `--version` | Show version information | - |
| `--help` | Show help message | - |

### Data Source

The CLI uses `create_mock_data()` which provides sample financial data for report generation with predefined values for testing and demonstration purposes.

## 🧑‍💻 Programmatic Usage

### Basic Document Generation

```python
from src.dataclass.final_report.report import FinancialReport
from src.docx_creator.financial_report_generator import create_mock_data, create_financial_report_document
from docx_creator.footnote_manager import WordFootnoteManager

# Create sample financial data
financial_report = create_mock_data()
financial_report.company_name = "My Company"

# Generate the Word document with native footnotes
doc, footnote_manager = create_financial_report_document(financial_report)

# Save with native footnotes
footnote_manager.save_document_with_footnotes("output_report.docx")
```

### Document Analysis

```python
from docx_creator.analyzer import DocumentAnalyzer

# Analyze a DOCX document
analyzer = DocumentAnalyzer("template.docx")
results = analyzer.analyze(verbose=True)

# Export formatting template
template = analyzer.export_formatting_template()
print(template)
# Output: {'footnote_references': {'font': 'Lucida Bright', 'size_pts': 10.0, ...}, ...}
```

### Custom Data Models

```python
from src.dataclass.final_report.investment import InvestmentRecord
from src.dataclass.final_report.capital_table import CapitalTableRow, CapitalTable

# Create custom investment record
investment_record = InvestmentRecord(
    cost_of_investment="500.0",
    last_funding_valuation="2000.0",
    net_asset_value="500.0"
)

# Create custom capital table
capital_table_rows = [
    CapitalTableRow(
        particulars="Founders",
        equity="50,000",
        series_i_ccps="-",
        series_ii_ccps="-",
        z1_z2_ccps="-",
        total="50,000",
        current_ownership="60.0%",
        fully_diluted="55.0%"
    ),
    # ... more rows
]
capital_table = CapitalTable(rows=capital_table_rows)
```

## 📋 Data Models

The project uses Pydantic models for structured, type-safe data:

### Core Models
- **`FootnoteRegistry`**: Manages document footnotes with auto-numbering
- **`FinancialReport`**: Complete report container with all sections
- **`InvestmentRecord`**: Investment cost, valuation, and net asset value
- **`CapitalTable`** & **`CapitalTableRow`**: Shareholder structure and ownership
- **`FundingDetails`**: Funding round information and valuations
- **`CompanyFinancials`** & **`FinancialQuarter`**: Quarterly financial metrics

### Footnote Models
- **`Footnote`**: Individual footnote with location and formatting
- **`FootnoteLocation`**: Enum for footnote positioning (investment_record, capital_table, etc.)

## 🎯 Native Footnotes

This tool generates **true Word footnotes** that:

- ✅ Create proper `footnotes.xml` in DOCX structure
- ✅ Use native Word footnote references with hyperlinks
- ✅ Match template formatting exactly (font, size, color, style)
- ✅ Position automatically at page bottoms
- ✅ Support superscript references with custom styling

### Footnote Formatting

Footnotes are template-matched with precise formatting:

**References:** Lucida Bright, 10pt, superscript, black
**Content:** Lucida Bright, 8pt, italic, black

## 🔍 Document Analyzer

The analyzer provides comprehensive insights:

### Analysis Features
- **📄 File Information**: Size, modification date
- **🏗️ Structure Analysis**: Internal folder and file structure
- **📝 Footnote Detection**: Native footnote presence and formatting
- **🎨 Formatting Extraction**: Font, size, color, style properties
- **🔗 Relationships**: Document part relationships and references
- **📋 Content Types**: DOCX part analysis and validation

### Sample Analysis Output

```bash
📊 DOCX Analysis Report: template.docx
============================================================

📄 File Information:
  Size: 2.21 MB (2,320,453 bytes)

📝 Footnotes Analysis:
  Has footnotes.xml: ✅ Yes
  Footnote count: 5
  Reference count: 3

  📋 Footnote Reference Formatting:
    Font: Lucida Bright
    Size: 10.0pt
    Alignment: superscript
    Color: #000000

✅ Analysis complete!
```

## 🧪 Testing

### Built-in Test Utilities

```python
from docx_creator.test_utils import test_docx_for_footnotes

# Test if document has native footnotes
has_footnotes = test_docx_for_footnotes("document.docx")
print("✅ Has native footnotes" if has_footnotes else "❌ No native footnotes")
```

### CLI Testing

```bash
# Generate and test in one command
poetry run docx-creator generate --output="test.docx" --test-footnotes --verbose
```

## 🔧 Development

### Running the Generator

```bash
# Activate Poetry environment
poetry shell

# Generate a sample document
poetry run docx-creator generate --output="sample.docx" --verbose
```

### Adding New Dependencies

```bash
# Production dependencies
poetry add package-name

# Development dependencies
poetry add --group dev package-name
```

### Code Structure

- **`src/dataclass/final_report/`**: All Pydantic data models organized by domain
- **`footnote_manager.py`**: Native Word footnote implementation
- **`financial_report_generator.py`**: Document generation and formatting
- **`analyzer/`**: Document analysis and formatting extraction
- **`test_utils.py`**: Testing and validation utilities

## 📦 Dependencies

### Core Dependencies
- **`python-docx`**: Word document creation and manipulation
- **`pydantic`**: Data validation using Python type annotations
- **`docopt`**: Command-line interface creation
- **`lxml`**: XML processing for advanced DOCX manipulation

### Development Dependencies
- **`pytest`**: Testing framework (future)
- **`black`**: Code formatting (future)
- **`flake8`**: Code linting (future)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📜 License

This project is licensed under the MIT License - see the LICENSE file for details.

## ✨ Recent Updates

- ✅ **Native Word Footnotes**: True footnote implementation with template matching
- ✅ **Modular Architecture**: Clean separation into focused modules
- ✅ **Document Analyzer**: Comprehensive DOCX analysis and formatting extraction
- ✅ **Template Matching**: Replicate formatting from existing documents
- ✅ **Enhanced CLI**: Added analyze command with export capabilities
- ✅ **Testing Utilities**: Built-in footnote validation and testing

## 🎯 Future Roadmap

- [ ] **Template Library**: Pre-built document templates for different industries
- [ ] **Data Import**: CSV, Excel, and JSON data import capabilities
- [ ] **Advanced Styling**: Theme support and style customization
- [ ] **Multi-language**: Internationalization support
- [ ] **Web Interface**: Browser-based document generation
- [ ] **API Endpoints**: REST API for document generation