#!/usr/bin/env python3
"""
DOCX Creator - Generate professional financial reports as Word documents.

Usage:
    docx-creator generate --output=PATH [--company=NAME] [--test-footnotes] [--verbose]
    docx-creator analyze --file=PATH [--export-template] [--verbose]
    docx-creator --version
    docx-creator --help

Options:
    --output=PATH      Output file path (required for generate)
    --file=PATH        Input DOCX file path (required for analyze)
    --company=NAME     Company name for the report [default: HAPPI PLANET]
    --test-footnotes   Test generated document for proper footnotes
    --export-template  Export formatting template from analyzed document
    --verbose         Enable verbose output
    --version         Show version information
    --help            Show this help message

Examples:
    docx-creator generate --output="generated_docs/acme_report.docx" --company="ACME Corp" --test-footnotes
    docx-creator generate --output="generated_docs/report.docx" --verbose
    docx-creator analyze --file="template.docx" --verbose
    docx-creator analyze --file="template.docx" --export-template

Author: AiStudio
Version: 0.1.0
"""

import sys
import os
from pathlib import Path
from typing import Dict, Any

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent / "src"))

from docopt import docopt
from docx_creator.financial_report_generator import (
    create_mock_data,
    create_financial_report_document
)
from docx_creator.test_utils import test_docx_for_footnotes
from docx_analyzer.analyzer import DocumentAnalyzer
from utils.logging import setup_logging, get_logger


def generate_report(args: Dict[str, Any]) -> None:
    """Generate a financial report document."""
    logger = get_logger(__name__)

    company_name = args["--company"]
    output_path = args["--output"]
    test_footnotes = args["--test-footnotes"]
    verbose = args["--verbose"]

    if not output_path:
        logger.error("Output path is required. Use --output=PATH")
        sys.exit(1)

    logger.info(f"Generating financial report for: {company_name}")
    logger.info(f"Output path: {output_path}")
    if test_footnotes:
        logger.debug("Will test footnotes after generation")

    try:
        # Create output directory if it doesn't exist
        output_dir = Path(output_path).parent
        output_dir.mkdir(parents=True, exist_ok=True)

        # Generate report using mock data
        financial_report = create_mock_data()
        financial_report.company_name = company_name

        # Create document with footnote manager
        doc, footnote_manager = create_financial_report_document(financial_report)

        # Save document with native footnotes
        footnote_manager.save_document_with_footnotes(output_path)

        logger.info("Document created successfully!")
        logger.info(f"File saved to: {output_path}")

        # Test footnotes if requested
        if test_footnotes:
            logger.debug("Testing document for footnotes...")

            has_footnotes = test_docx_for_footnotes(output_path)
            if not has_footnotes:
                logger.warning("Document does not contain true Word footnotes")

    except Exception as e:
        logger.error(f"Error generating report: {e}")
        if verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


def analyze_document(args: Dict[str, Any]) -> None:
    """Analyze a DOCX document structure and formatting."""
    logger = get_logger(__name__)

    file_path = args["--file"]
    export_template = args["--export-template"]
    verbose = args["--verbose"]

    if not file_path:
        logger.error("File path is required for analyze command. Use --file=PATH")
        sys.exit(1)

    if not Path(file_path).exists():
        logger.error(f"File not found: {file_path}")
        sys.exit(1)

    logger.info(f"Analyzing document: {file_path}")
    if export_template:
        logger.debug("Will export formatting template")

    try:
        # Analyze the document
        analyzer = DocumentAnalyzer(file_path)
        results = analyzer.analyze(verbose=verbose)

        # Export template if requested
        if export_template:
            template = analyzer.export_formatting_template()
            if template:
                template_file = Path(file_path).stem + "_formatting_template.json"
                import json
                with open(template_file, 'w') as f:
                    json.dump(template, f, indent=2)
                logger.info(f"Formatting template exported to: {template_file}")
            else:
                logger.warning("No footnote formatting found to export")

        if not verbose:
            # Show summary for non-verbose mode
            footnotes = results.get('footnotes', {})
            if footnotes.get('has_footnotes_xml'):
                logger.info(f"Document has native footnotes ({footnotes['footnote_count']} total)")
            else:
                logger.warning("Document does not have native footnotes")

    except Exception as e:
        logger.error(f"Error analyzing document: {e}")
        if verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


def main():
    """Main CLI entry point."""
    args = docopt(__doc__, version="DOCX Creator 0.1.0")

    # Set up logging based on verbosity
    verbose = args.get("--verbose", False)
    level = "DEBUG" if verbose else "INFO"
    setup_logging(level=level, log_to_file=False)

    logger = get_logger(__name__)
    logger.debug(f"CLI started with args: {args}")

    if args["generate"]:
        generate_report(args)
    elif args["analyze"]:
        analyze_document(args)
    else:
        print(__doc__)  # Keep this as print since it's help text

if __name__ == "__main__":
    main()
