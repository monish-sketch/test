"""Financial data models for final report generation."""

from typing import List
from pydantic import BaseModel, Field


class FinancialQuarter(BaseModel):
    """Model for quarterly financial data"""
    quarter_name: str = Field(..., description="Quarter name (e.g., JFM 2024)")
    net_revenue: str = Field(..., description="Net revenue in INR Mn")
    ebitda: str = Field(..., description="EBITDA in INR Mn")
    gross_cash: str = Field(..., description="Gross cash in INR Mn")
    debt_inr_mn: str = Field(default="-", description="Debt in INR Mn")
    headcount: str = Field(..., description="Headcount")


class CompanyFinancials(BaseModel):
    """Model for company financial data"""
    quarters: List[FinancialQuarter] = Field(..., description="List of quarterly financial data")
