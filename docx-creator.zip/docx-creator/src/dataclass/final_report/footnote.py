"""Footnote models for final report generation."""

from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field


class FootnoteLocation(str, Enum):
    """Enum for footnote locations in the document"""
    INVESTMENT_RECORD = "investment_record"
    CAPITAL_TABLE = "capital_table"
    FUNDING_DETAILS = "funding_details"
    COMPANY_FINANCIALS = "company_financials"


class Footnote(BaseModel):
    """Model for individual footnotes with proper relationships"""
    id: str = Field(..., description="Unique footnote identifier")
    location: FootnoteLocation = Field(..., description="Document section where footnote appears")
    element: str = Field(..., description="Specific element (e.g., 'cost_of_investment', 'z1_z2_ccps')")
    text: str = Field(..., description="Footnote text content")
    auto_number: Optional[int] = Field(None, description="Auto-generated footnote number")


class FootnoteRegistry(BaseModel):
    """Registry to manage all footnotes in the document"""
    footnotes: List[Footnote] = Field(default_factory=list, description="List of all footnotes")
    counter: int = Field(default=0, description="Internal counter for auto-numbering")

    def add_footnote(self, location: FootnoteLocation, element: str, text: str) -> str:
        """Add a footnote and return its ID"""
        self.counter += 1
        footnote_id = f"fn_{self.counter}"
        footnote = Footnote(
            id=footnote_id,
            location=location,
            element=element,
            text=text,
            auto_number=self.counter
        )
        self.footnotes.append(footnote)
        return footnote_id

    def get_footnote_by_element(self, location: FootnoteLocation, element: str) -> Optional[Footnote]:
        """Get footnote for a specific element"""
        for footnote in self.footnotes:
            if footnote.location == location and footnote.element == element:
                return footnote
        return None

    def get_footnotes_by_location(self, location: FootnoteLocation) -> List[Footnote]:
        """Get all footnotes for a specific location"""
        return [fn for fn in self.footnotes if fn.location == location]
