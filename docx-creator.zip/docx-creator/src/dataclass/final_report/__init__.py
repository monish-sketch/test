"""Final report models for document generation."""
