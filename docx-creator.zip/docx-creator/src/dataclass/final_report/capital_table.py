"""Capital table models for final report generation."""

from typing import List
from pydantic import BaseModel, Field


class CapitalTableRow(BaseModel):
    """Model for individual capital table row"""
    particulars: str = Field(..., description="Name of the stakeholder")
    equity: str = Field(..., description="Equity amount")
    series_i_ccps: str = Field(..., description="Series I CCPS amount")
    series_ii_ccps: str = Field(..., description="Series II CCPS amount")
    z1_z2_ccps: str = Field(..., description="Z1/Z2 CCPS amount")
    total: str = Field(..., description="Total amount")
    current_ownership: str = Field(..., description="Current ownership percentage")
    fully_diluted: str = Field(..., description="Fully diluted percentage")


class CapitalTable(BaseModel):
    """Model for capital table data"""
    rows: List[CapitalTableRow] = Field(..., description="List of capital table rows")
