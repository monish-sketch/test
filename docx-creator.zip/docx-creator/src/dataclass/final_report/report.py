"""Main financial report model."""

from pydantic import BaseModel, Field

from dataclass.final_report.investment import InvestmentRecord
from dataclass.final_report.capital_table import CapitalTable
from dataclass.final_report.funding import FundingDetails
from dataclass.final_report.financials import CompanyFinancials
from dataclass.final_report.footnote import FootnoteRegistry


class FinancialReport(BaseModel):
    """Main model for the complete financial report"""
    company_name: str = Field(default="HAPPI PLANET", description="Company name")
    investment_record: InvestmentRecord = Field(..., description="Investment record data")
    capital_table: CapitalTable = Field(..., description="Capital table data")
    funding_details: FundingDetails = Field(..., description="Funding details")
    company_financials: CompanyFinancials = Field(..., description="Company financial data")
    footnote_registry: FootnoteRegistry = Field(default_factory=FootnoteRegistry, description="Registry of all footnotes")
    page_number: int = Field(default=34, description="Page number")
