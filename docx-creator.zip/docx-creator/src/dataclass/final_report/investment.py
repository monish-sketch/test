"""Investment record models for final report generation."""

from pydantic import BaseModel, Field


class InvestmentRecord(BaseModel):
    """Model for investment record data"""
    cost_of_investment: str = Field(default="84.6", description="Cost of investment in INR Mn")
    last_funding_valuation: str = Field(default="384.6", description="Last funding round company valuation in INR Mn")
    net_asset_value: str = Field(default="84.6", description="Net asset value in INR Mn")
