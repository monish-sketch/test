"""Funding details models for final report generation."""

from pydantic import BaseModel, Field


class FundingDetails(BaseModel):
    """Model for funding details"""
    series_type: str = Field(default="Seed Series II", description="Type of funding series")
    date: str = Field(default="December 2023", description="Funding date")
    pre_money: str = Field(default="300.0", description="Pre-money valuation in INR Mn")
    total_money_raised: str = Field(default="84.6", description="Total money raised in INR Mn")
    post_money: str = Field(default="384.6", description="Post-money valuation in INR Mn")
    fireside_ventures: str = Field(default="84.6", description="Fireside Ventures investment in INR Mn")
