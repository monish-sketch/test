"""Dataclass for share_cap_table table."""

from dataclasses import dataclass
from typing import Optional
from datetime import datetime


@dataclass
class ShareCapTable:
    """Dataclass representing a record in the share_cap_table table."""

    # Core share capital data
    file_id: int  # Foreign key to files.id
    company_id: int  # Foreign key to company.id
    category: str = "Other"  # share_category enum: ["Other", "Founder", "Fireside", "ESOP"], default "Other"
    shareholder_name: str = ""
    number_of_shares: int = 0  # Must be >= 0 (check constraint)
    series: str = ""

    # Auto-generated fields
    id: Optional[int] = None  # Primary key, auto-generated (identity)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    def __post_init__(self):
        """Validate enum values and constraints."""
        valid_categories = ["Other", "Founder", "Fireside", "ESOP"]
        if self.category not in valid_categories:
            raise ValueError(f"Invalid category: {self.category}. Must be one of {valid_categories}")

        if self.number_of_shares < 0:
            raise ValueError(f"Number of shares must be >= 0, got {self.number_of_shares}")

    @property
    def is_founder_shares(self) -> bool:
        """Check if these are founder shares."""
        return self.category == "Founder"

    @property
    def is_fireside_shares(self) -> bool:
        """Check if these are Fireside Ventures shares."""
        return self.category == "Fireside"

    @property
    def is_esop_shares(self) -> bool:
        """Check if these are ESOP shares."""
        return self.category == "ESOP"

    @property
    def has_shares(self) -> bool:
        """Check if there are any shares."""
        return self.number_of_shares > 0

    def __str__(self):
        """String representation of the share capital entry."""
        return f"{self.shareholder_name} ({self.category}) - {self.series}: {self.number_of_shares:,} shares"
