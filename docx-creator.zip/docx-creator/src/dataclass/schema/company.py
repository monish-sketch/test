"""Dataclass for company table."""

from dataclasses import dataclass
from typing import Optional, List
from datetime import datetime


@dataclass
class Company:
    """Dataclass representing a record in the company table."""

    # Core company data
    registered_name: str
    common_name: str  # Unique
    list_of_funds: Optional[List[str]] = None  # Array of fund_type enum: ["Fund 1", "Fund 2", "Fund 3"]

    # Auto-generated fields
    id: Optional[int] = None  # Primary key, auto-generated (identity)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    def __post_init__(self):
        """Validate fund types if provided."""
        if self.list_of_funds:
            valid_funds = ["Fund 1", "Fund 2", "Fund 3"]
            for fund in self.list_of_funds:
                if fund not in valid_funds:
                    raise ValueError(f"Invalid fund type: {fund}. Must be one of {valid_funds}")

    @property
    def display_name(self) -> str:
        """Get the common name for display purposes."""
        return self.common_name

    @property
    def has_funds(self) -> bool:
        """Check if company has funds associated."""
        return self.list_of_funds is not None and len(self.list_of_funds) > 0

    def __str__(self):
        """String representation of the company."""
        funds_str = f" (Funds: {', '.join(self.list_of_funds)})" if self.has_funds else ""
        return f"{self.common_name}{funds_str}"
