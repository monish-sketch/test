"""Dataclass for files table."""

from dataclasses import dataclass
from typing import Optional
from datetime import datetime, date


@dataclass
class File:
    """Dataclass representing a record in the files table."""

    # Core file data
    type: str  # file_type enum: ["mis", "commentary", "draft_report", "final_report"]
    path: str  # File path/ID
    owner: str
    owner_type: str  # owner_type enum: ["company", "investment_team", "finance", "final_report"]
    asof_date: date
    file_name: Optional[str] = None
    company_id: Optional[int] = None  # Foreign key to company.id

    # Auto-generated fields
    id: Optional[int] = None  # Primary key, auto-generated (identity)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    def __post_init__(self):
        """Validate enum values."""
        valid_file_types = ["mis", "commentary", "draft_report", "final_report"]
        if self.type not in valid_file_types:
            raise ValueError(f"Invalid file type: {self.type}. Must be one of {valid_file_types}")

        valid_owner_types = ["company", "investment_team", "finance", "final_report"]
        if self.owner_type not in valid_owner_types:
            raise ValueError(f"Invalid owner type: {self.owner_type}. Must be one of {valid_owner_types}")

    @property
    def is_mis_file(self) -> bool:
        """Check if this is a MIS file."""
        return self.type == "mis"

    @property
    def is_commentary_file(self) -> bool:
        """Check if this is a commentary file."""
        return self.type == "commentary"

    @property
    def is_report_file(self) -> bool:
        """Check if this is a report file (draft or final)."""
        return self.type in ["draft_report", "final_report"]

    @property
    def display_name(self) -> str:
        """Get display name for the file."""
        return self.file_name or self.path

    def __str__(self):
        """String representation of the file."""
        return f"{self.display_name} ({self.type}) - {self.owner}"
