"""Schema dataclasses for Supabase tables."""
