"""Dataclass for quarterly_attributes table."""

from dataclasses import dataclass
from typing import Optional
from decimal import Decimal
from datetime import datetime


@dataclass
class QuarterlyAttribute:
    """Dataclass representing a record in the quarterly_attributes table."""

    # Core identifiers
    file_id: int
    company_id: int
    quarter: str

    # Attribute data
    attribute_name: str  # The particulars/description
    attribute_type: str  # 'financials' or 'headcount' (enum)
    attribute_number: Optional[Decimal] = None
    attribute_text: Optional[str] = None
    attribute_subtype_1: Optional[str] = None
    attribute_subtype_2: Optional[str] = None
    attribute_dimension: Optional[str] = None  # Dimension and multiplier (e.g. INR Mn represents 10^6 INR)

    # Auto-generated fields
    id: Optional[int] = None  # Primary key, auto-generated
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    def __post_init__(self):
        """Validate attribute_type values."""
        valid_types = ['financials', 'headcount']
        if self.attribute_type not in valid_types:
            raise ValueError(f"attribute_type must be one of {valid_types}, got {self.attribute_type}")

    @property
    def is_financial(self) -> bool:
        """Check if this attribute is a financial metric."""
        return self.attribute_type == 'financials'

    @property
    def is_headcount(self) -> bool:
        """Check if this attribute is a headcount metric."""
        return self.attribute_type == 'headcount'

    @property
    def has_dimension(self) -> bool:
        """Check if this attribute has a dimension (e.g., 'INR Mn')."""
        return self.attribute_dimension is not None or self.attribute_text is not None

    @property
    def has_subtypes(self) -> bool:
        """Check if this attribute has subtypes defined."""
        return self.attribute_subtype_1 is not None or self.attribute_subtype_2 is not None

    def __str__(self):
        """String representation of the quarterly attribute."""
        dimension = self.attribute_dimension or self.attribute_text or ''
        return f"{self.attribute_name} ({self.quarter}): {self.attribute_number} {dimension}".strip()
