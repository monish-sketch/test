"""Dataclass for commentary table."""

from dataclasses import dataclass
from typing import Optional
from datetime import datetime


@dataclass
class Commentary:
    """Dataclass representing a record in the commentary table."""

    # Core commentary data
    file_id: int  # Foreign key to files.id
    company_id: int  # Foreign key to company.id
    quarter: str  # Quarter period (e.g., "JFM 2024")
    commentary: str  # The actual commentary text

    # Auto-generated fields
    id: Optional[int] = None  # Primary key, auto-generated (identity)
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    @property
    def is_empty(self) -> bool:
        """Check if commentary is empty or whitespace."""
        return not self.commentary or self.commentary.strip() == ""

    @property
    def word_count(self) -> int:
        """Get approximate word count of the commentary."""
        return len(self.commentary.split()) if self.commentary else 0

    @property
    def preview(self) -> str:
        """Get a preview of the commentary (first 100 characters)."""
        if not self.commentary:
            return ""
        return self.commentary[:100] + "..." if len(self.commentary) > 100 else self.commentary

    def __str__(self):
        """String representation of the commentary."""
        return f"Commentary {self.quarter} (Company {self.company_id}): {self.preview}"
