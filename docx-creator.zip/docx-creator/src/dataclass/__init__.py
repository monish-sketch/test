"""Dataclass package with schema and final report models.

This package contains two main categories of models:

1. Schema models (src/dataclass/schema/): Dataclasses that mirror your Supabase database tables
2. Final report models (src/dataclass/final_report/): Pydantic models for document generation

Usage:

Schema models (for database operations):
    from dataclass.schema.quarterly_attributes import QuarterlyAttribute
    from dataclass.schema.company import Company
    from dataclass.schema.files import File
    from dataclass.schema.commentary import Commentary
    from dataclass.schema.share_cap_table import ShareCapTable

Final report models (for document generation):
    from dataclass.final_report.report import FinancialReport
    from dataclass.final_report.footnote import FootnoteRegistry
    from dataclass.final_report.investment import InvestmentRecord
    from dataclass.final_report.capital_table import CapitalTable
    from dataclass.final_report.funding import FundingDetails
    from dataclass.final_report.financials import CompanyFinancials
"""
