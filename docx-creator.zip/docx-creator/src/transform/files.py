"""File list transformer for Google Drive files."""

import datetime
from typing import Dict, Optional
import pandas as pd

from google_drive.extractor import GoogleDriveExtractor
from google_drive.config import OFFICE_MIME_TYPES
from db.db import SupabaseDB


class FileListTransformer:
    """Transform Google Drive file listings into structured data for database storage."""

    def __init__(self, extractor: GoogleDriveExtractor, db: SupabaseDB):
        self.extractor = extractor
        self.db = db

        # Hardcoded configurations
        self.ignore_mime_types = [
            'application/pdf',
            'application/vnd.google-apps.folder'
        ]

        self.asof_date_map = {
            "19yYx7qjCADnS8ligMzO6ew7F-_uqmmlF": datetime.date(2025, 6, 30),
            "14vXyasqWexxaMoYATCjBgVu4c8GDTSoh": datetime.date(2025, 3, 31),
        }

        self.keep_cols_rename = {
            'name': 'file_name',
            'file_type': 'type',
            'id': 'path'
        }

        self.other_keep_cols = ['asof_date', 'owner_type', 'owner']
        self.default_company_id = 29

    def _determine_file_type(self, row: pd.Series) -> Optional[str]:
        """Determine file type based on mime type and name."""
        if row['mimeType'] == OFFICE_MIME_TYPES["excel"]:
            return "mis"
        if row['mimeType'] == OFFICE_MIME_TYPES["word"]:
            if "quarter" in row['name'].lower():
                return "final_report"
            else:
                return "commentary"
        return None

    def _determine_owner_type(self, row: pd.Series) -> Optional[str]:
        """Determine owner type based on mime type and name."""
        if row['mimeType'] == OFFICE_MIME_TYPES["excel"]:
            return "company"
        if row['mimeType'] == OFFICE_MIME_TYPES["word"]:
            if "quarter" in row['name'].lower():
                return "final_report"
            else:
                return "investment_team"
        return None

    def _determine_owner(self, row: pd.Series) -> Optional[str]:
        """Determine owner based on mime type and name."""
        if row['mimeType'] == OFFICE_MIME_TYPES["excel"]:
            return "Company CFO"
        if row['mimeType'] == OFFICE_MIME_TYPES["word"]:
            if "quarter" in row['name'].lower():
                return "Partners"
            return "Rahul Mehta"
        return None

    def _get_company_mappings(self) -> tuple:
        """Get company name mappings from database."""
        company_df = self.db.get_all_records("company")
        company_df['registered_name_no_pvt_ltd'] = company_df['registered_name'].apply(
            lambda x: str(x).replace(' Pvt. Ltd.', '').lower()
        )
        company_df['lower_name'] = company_df['common_name'].str.lower()

        company_lower_name_map = dict(zip(company_df['lower_name'], company_df['id']))
        registered_name_map = dict(zip(company_df['registered_name_no_pvt_ltd'], company_df['id']))

        return company_lower_name_map, registered_name_map

    def _get_company_id(self, row: pd.Series, company_lower_name_map: Dict, registered_name_map: Dict) -> Optional[int]:
        """Determine company ID based on file name."""
        file_name = row['file_name'].lower()
        company_ids = []

        for key, value in company_lower_name_map.items():
            if key in file_name:
                company_ids.append(value)

        for key, value in registered_name_map.items():
            if key in file_name:
                company_ids.append(value)

        company_ids = list(set(company_ids))

        if len(company_ids) > 1:
            return None
        if len(company_ids) == 1:
            return int(company_ids[0])
        return None

    def transform_files_list(self, folder_id: str, recursive: bool = True) -> pd.DataFrame:
        """Transform Google Drive files list into structured DataFrame."""
        # List files
        files = self.extractor.list_files(folder_id, recursive=recursive)
        files_df = pd.DataFrame(files)

        # Filter out unwanted mime types
        remove_flag = files_df['mimeType'].isin(self.ignore_mime_types)
        files_df = files_df[~remove_flag].copy()

        # Apply transformations
        files_df['file_type'] = files_df.apply(self._determine_file_type, axis=1)
        files_df['owner_type'] = files_df.apply(self._determine_owner_type, axis=1)
        files_df['owner'] = files_df.apply(self._determine_owner, axis=1)

        # Add asof_date
        files_df['asof_date'] = files_df['parents'].apply(
            lambda x: self.asof_date_map.get(x[0]) if x else None
        )

        # Keep and rename columns
        files_df = files_df[list(self.keep_cols_rename.keys()) + self.other_keep_cols].rename(
            columns=self.keep_cols_rename
        )

        # Get company mappings and add company_id
        company_lower_name_map, registered_name_map = self._get_company_mappings()
        files_df['company_id'] = files_df.apply(
            lambda row: self._get_company_id(row, company_lower_name_map, registered_name_map),
            axis=1
        ).fillna(self.default_company_id).astype(int)

        return files_df
