"""Base transformer class for common file processing patterns."""

from abc import ABC, abstractmethod
from typing import List, Optional, Tuple
import pandas as pd

from google_drive.extractor import GoogleDriveExtractor
from db.db import SupabaseDB
from utils.logging import get_logger

logger = get_logger(__name__)


class BaseTransformer(ABC):
    """Base class for transformers that process files into structured data."""

    def __init__(self, extractor: GoogleDriveExtractor, db: SupabaseDB):
        """Initialize transformer with extractor and database instances."""
        self.extractor = extractor
        self.db = db

    @abstractmethod
    def _process_single_file(self, file_row: pd.Series) -> Optional[pd.DataFrame]:
        """Process a single file and return DataFrame or None if processing failed.

        Args:
            file_row: Row from files DataFrame containing file metadata

        Returns:
            Processed DataFrame or None if processing failed
        """

    def _get_files_for_processing(self, file_type_filter: str) -> pd.DataFrame:
        """Get files DataFrame with company info for processing.

        Args:
            file_type_filter: Type of files to filter for (e.g., 'mis', 'commentary')

        Returns:
            DataFrame with file and company information merged
        """
        company_df = self.db.get_all_records("company")[['id', 'common_name']]
        files_df = self.db.get_all_records("files", simple_filter={'type': file_type_filter})
        files_df = files_df.merge(company_df, left_on='company_id', right_on='id', how='left')
        return files_df

    def _batch_process_files(self, files_df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
        """Process multiple files in batch and collect results.

        Args:
            files_df: DataFrame containing file information

        Returns:
            Tuple of (combined_results_df, list_of_error_files)
        """
        processed_dfs = []
        error_files = []

        logger.info(f"Processing {len(files_df)} files...")

        for _, file_row in files_df.iterrows():
            result_df = self._process_single_file(file_row)

            if result_df is not None:
                processed_dfs.append(result_df)
            else:
                error_files.append(file_row['file_name'])

        # Handle results
        if not processed_dfs:
            logger.warning("No files processed successfully")
            return pd.DataFrame(), error_files

        # Combine all results
        combined_df = pd.concat(processed_dfs, ignore_index=True)
        logger.info(f"Successfully processed {len(processed_dfs)} files, "
                   f"{len(error_files)} files had errors")

        # Apply post-processing if data exists
        if not combined_df.empty:
            combined_df = self._post_process_combined_data(combined_df)

        return combined_df, error_files

    def _post_process_combined_data(self, combined_df: pd.DataFrame) -> pd.DataFrame:
        """Post-process the combined data after concatenation.

        Override this method in subclasses if additional processing is needed
        after combining all file results.

        Args:
            combined_df: Combined DataFrame from all processed files

        Returns:
            Post-processed DataFrame
        """
        return combined_df
