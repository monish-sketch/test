"""Quarterly attribute transformer for processing financial data tables."""

from typing import List, Optional, Tuple, Dict
import pandas as pd

from transform.base import BaseTransformer
from utils.df import find_next_empty_row, remove_identical_adjacent_columns


class QuarterlyAttributeTransformer(BaseTransformer):
    """Transform quarterly financial attributes from spreadsheets into structured data."""

    def __init__(self, extractor, db):
        super().__init__(extractor, db)

        # Hardcoded configurations
        self.file_type_filter = 'mis'
        self.financial_sheet_keyword = 'financial'
        self.processed_data_key = 'processed_data'
        self.particulars_keyword = 'particulars'
        self.expected_table_count = 4
        self.first_table_index = 0

        # Column detection patterns for quarters/years
        self.quarter_strings = ['JFM', 'AMJ', 'JAS', 'OND', 'Q1', 'Q2', 'Q3', 'Q4']
        self.year_strings = ['2020', '2021', '2022', '2023', '2024', '2025', '2026',
                           '2027', '2028', '2029', '2030', '20', '21', '22', '23',
                           '24', '25', '26', '27', '28', '29', '30']
        self.inception_strings = ["inceptiontilldate"]

        # Attribute classification
        self.headcount_keyword = 'head'
        self.dimension_keyword = 'inr mn'
        self.attribute_types = {
            'headcount': 'headcount',
            'financials': 'financials'
        }
        self.dimension_mapping = {
            'inr_mn': 'INR Mn'
        }

        # Expected column names
        self.particulars_column = 'Particulars'
        self.index_cols = ['file_id', 'company_id', 'Particulars']


    def _get_particulars_row(self, df: pd.DataFrame, row_number: int = 0) -> Optional[int]:
        """Find the row where particulars table starts."""
        for index, row in df.iterrows():
            if index > row_number and self.particulars_keyword in str(row.iloc[0]).lower():
                return index
        return None

    def _get_particulars_last_columns(self, df: pd.DataFrame, particulars_row: int) -> int:
        """Find the last column containing quarter/year data."""
        row = df.iloc[particulars_row]
        count = 0

        for _, item in row.items():
            if self.particulars_keyword in str(item).lower():
                count += 1
                continue

            item_str = str(item).lower().replace(' ', '').replace('\n', '')
            original_item_str_len = len(item_str)

            # Remove known patterns
            for quarter in self.quarter_strings:
                item_str = item_str.replace(quarter.lower(), '')
            for year in self.year_strings:
                item_str = item_str.replace(year.lower(), '')
            for inception in self.inception_strings:
                item_str = item_str.replace(inception.lower(), '')

            if len(item_str) < original_item_str_len:
                count += 1
            else:
                break
        return count

    def _get_all_particulars_tables(self, df: pd.DataFrame) -> List[Dict]:
        """Get all particulars table boundaries."""
        tables = []
        start_row = self._get_particulars_row(df)

        if start_row is None:
            return tables

        end_col = self._get_particulars_last_columns(df, start_row)
        end_row = find_next_empty_row(df, start_row, end_col)

        tables.append({
            "start_row": start_row,
            "end_row": end_row,
            "end_col": end_col,
        })

        while start_row is not None and end_row is not None:
            start_row = self._get_particulars_row(df, end_row)
            if start_row is not None:
                end_col = self._get_particulars_last_columns(df, start_row)
                end_row = find_next_empty_row(df, start_row, end_col)
                if end_row is None:
                    end_row = len(df)
                tables.append({
                    "start_row": start_row,
                    "end_row": end_row,
                    "end_col": end_col,
                })

        return tables


    def _get_attribute_type(self, particulars_text: str) -> str:
        """Determine attribute type based on particulars text."""
        if self.headcount_keyword in str(particulars_text).lower():
            return self.attribute_types['headcount']
        return self.attribute_types['financials']

    def _get_attribute_dimension(self, particulars_text: str) -> Optional[str]:
        """Determine attribute dimension based on particulars text."""
        if self.dimension_keyword in str(particulars_text).lower():
            return self.dimension_mapping['inr_mn']
        return None

    def _process_single_file(self, file_row: pd.Series) -> Optional[pd.DataFrame]:
        """Process a single file's financial tables."""
        try:
            sheets_data = self.extractor.read_spreadsheet(file_row['path'])

            # Find financial sheet
            financial_sheets = [
                sheet_name for sheet_name in sheets_data.keys()
                if self.financial_sheet_keyword in str(sheet_name).lower()
            ]

            if len(financial_sheets) == 0:
                return None
            if len(financial_sheets) > 1:
                return None

            sheet_data = sheets_data.get(financial_sheets[0])
            if self.processed_data_key not in sheet_data:
                return None

            processed_df = sheet_data[self.processed_data_key]

            # Find all particulars tables
            tables = self._get_all_particulars_tables(processed_df)
            if len(tables) != self.expected_table_count:
                return None

            # Process first table only
            first_table = tables[self.first_table_index]

            # Extract table data
            table_df = processed_df.iloc[
                first_table['start_row']:first_table['end_row'],
                :first_table['end_col']
            ]

            # Remove identical adjacent columns
            table_df = remove_identical_adjacent_columns(table_df)

            # Set up columns and data
            data_df = table_df.iloc[1:].copy()
            data_df.columns = table_df.iloc[0]
            data_df = data_df.dropna(axis=1, how='all').copy()

            # Add file metadata
            data_df['file_id'] = file_row['id_x']
            data_df['company_id'] = file_row['company_id']

            return data_df

        except Exception:
            return None

    def _post_process_combined_data(self, combined_df: pd.DataFrame) -> pd.DataFrame:
        """Melt and classify attributes after combining all quarterly data."""
        # Melt the dataframe
        melt_cols = [col for col in combined_df.columns if col not in self.index_cols]
        melted_df = combined_df.melt(
            id_vars=self.index_cols,
            value_vars=melt_cols,
            var_name='quarter',
            value_name='attribute_number'
        )

        # Add attribute classifications
        melted_df['attribute_type'] = melted_df[self.particulars_column].apply(self._get_attribute_type)
        melted_df['attribute_text'] = melted_df[self.particulars_column].apply(self._get_attribute_dimension)
        melted_df['attribute_name'] = melted_df[self.particulars_column]
        melted_df = melted_df.drop(columns=[self.particulars_column])

        return melted_df

    def transform_quarterly_attributes(self) -> Tuple[pd.DataFrame, List[str]]:
        """Transform all quarterly attributes from MIS files."""
        files_df = self._get_files_for_processing(self.file_type_filter)
        return self._batch_process_files(files_df)
