"""Cap table transformer for processing share capital tables."""

from typing import List, Optional, Tuple, Dict
import pandas as pd

from transform.base import BaseTransformer
from utils.df import find_next_empty_row


class CapTableTransformer(BaseTransformer):
    """Transform share capital tables from spreadsheets into structured data."""

    def __init__(self, extractor, db):
        super().__init__(extractor, db)

        # Hardcoded configurations
        self.allowed_categories = ['Other', 'Founder', 'Fireside', 'ESOP']
        self.default_category = 'Other'
        self.file_type_filter = 'mis'
        self.share_sheet_keyword = 'share'
        self.cap_table_marker = 'Share Capital Table'
        self.raw_data_key = 'raw_data'
        self.zero_share_indicators = ['-', '']

        # Column detection patterns
        self.percentage_pattern = '%'
        self.nan_values = ['nan', 'na']
        self.date_keywords = ['date']
        self.company_keywords = ['company', 'moxie']  # had to add Moxie under company keywords
        self.shareholder_keywords = ['shareholder']
        self.category_keywords = ['category']

        # Output column that's expected to exist (case-sensitive)
        self.category_column_name = 'Category'

    def _get_category(self, category: str) -> str:
        """Map category to allowed categories."""
        if category in self.allowed_categories:
            return category
        return self.default_category


    def _get_share_cap_table_start_row(self, df: pd.DataFrame) -> Optional[int]:
        """Find the row where Share Capital Table starts."""
        for index, row in df.iterrows():
            if self.cap_table_marker in str(row.iloc[0]):
                return index + 1
        return None

    def _get_share_cap_table_start_and_end_row(self, df: pd.DataFrame) -> Tuple[Optional[int], Optional[int]]:
        """Get start and end rows for share capital table."""
        start_row = self._get_share_cap_table_start_row(df)
        if start_row is None:
            return None, None
        end_row = find_next_empty_row(df, start_row)
        return start_row, end_row

    def _detect_column_types(self, columns: pd.Index) -> Dict[str, List[str]]:
        """Detect different types of columns based on patterns."""
        percentage_cols = [col for col in columns if self.percentage_pattern in str(col)]
        nan_cols = [col for col in columns if col in self.nan_values]

        date_cols = [
            col for col in columns
            if any(keyword in str(col).lower() for keyword in self.date_keywords)
            and col not in percentage_cols and col not in nan_cols
        ]

        company_cols = [
            col for col in columns
            if any(keyword in str(col).lower() for keyword in self.company_keywords)
            and col not in percentage_cols and col not in nan_cols
        ]

        shareholder_cols = [
            col for col in columns
            if any(keyword in str(col).lower() for keyword in self.shareholder_keywords)
            and col not in percentage_cols and col not in nan_cols
        ]

        category_cols = [
            col for col in columns
            if any(keyword in str(col).lower() for keyword in self.category_keywords)
            and col not in percentage_cols and col not in nan_cols
        ]

        return {
            'percentage': percentage_cols,
            'nan': nan_cols,
            'date': date_cols,
            'company': company_cols,
            'shareholder': shareholder_cols,
            'category': category_cols
        }

    def _process_single_file(self, file_row: pd.Series) -> Optional[pd.DataFrame]:
        """Process a single file's share capital table."""
        try:
            sheets_data = self.extractor.read_spreadsheet(file_row['path'])

            # Find sheet with share capital data
            share_sheets = [
                sheet_name for sheet_name in sheets_data.keys()
                if self.share_sheet_keyword in str(sheet_name).lower()
            ]

            if len(share_sheets) == 0:
                return None
            if len(share_sheets) > 1:
                return None

            sheet_data = sheets_data.get(share_sheets[0])
            if self.raw_data_key not in sheet_data:
                return None

            raw_df = sheet_data[self.raw_data_key]

            # Find table boundaries
            start_row, end_row = self._get_share_cap_table_start_and_end_row(raw_df)
            if start_row is None or end_row is None:
                return None

            # Extract and process table
            df = raw_df.iloc[start_row + 1:end_row].copy()
            df.columns = raw_df.iloc[start_row].apply(lambda x: str(x).strip())

            # Detect column types
            col_types = self._detect_column_types(df.columns)

            # Validate required columns
            if len(col_types['shareholder']) != 1:
                return None
            if len(col_types['category']) != 1:
                return None

            shareholder_col = col_types['shareholder'][0]
            category_col = col_types['category'][0]

            # Remove unwanted columns
            drop_cols = (col_types['company'] + col_types['date'] +
                        col_types['nan'] + col_types['percentage'])
            df = df.drop(columns=list(set(drop_cols))).copy()

            # Melt the dataframe
            index_cols = [category_col, shareholder_col]
            melt_cols = [col for col in df.columns if col not in index_cols]

            melted_df = df.melt(
                id_vars=index_cols,
                value_vars=melt_cols,
                var_name='series',
                value_name='number_of_shares'
            ).dropna(subset=[self.category_column_name])

            # Process share numbers
            melted_df['number_of_shares'] = melted_df['number_of_shares'].apply(
                lambda x: 0 if str(x).replace(' ', '') in self.zero_share_indicators else x
            )
            melted_df['number_of_shares'] = melted_df['number_of_shares'].fillna(0).astype(int)
            melted_df = melted_df[melted_df['number_of_shares'] > 0]

            # Apply category mapping
            melted_df['category'] = melted_df[self.category_column_name].apply(self._get_category)

            # Clean up columns
            melted_df['shareholder_name'] = melted_df[shareholder_col].str.strip()
            melted_df['series'] = melted_df['series'].str.strip()
            melted_df = melted_df.drop(columns=[self.category_column_name, shareholder_col])

            # Add file metadata
            melted_df['file_id'] = file_row['id_x']
            melted_df['company_id'] = file_row['company_id']

            return melted_df

        except Exception:
            return None

    def _post_process_combined_data(self, combined_df: pd.DataFrame) -> pd.DataFrame:
        """Clean up category data after combining all cap tables."""
        # Clean up "Other Investor" to "Other"
        combined_df['category'] = combined_df['category'].str.replace("Other Investor", "Other")
        return combined_df

    def transform_cap_tables(self) -> Tuple[pd.DataFrame, List[str]]:
        """Transform all cap tables from MIS files."""
        files_df = self._get_files_for_processing(self.file_type_filter)
        return self._batch_process_files(files_df)
