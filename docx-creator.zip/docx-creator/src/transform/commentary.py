"""Commentary transformer for processing Word document commentary tables."""

from typing import List, Optional, Tuple
import pandas as pd

from transform.base import BaseTransformer


class CommentaryTransformer(BaseTransformer):
    """Transform commentary tables from Word documents into structured data."""

    def __init__(self, extractor, db):
        super().__init__(extractor, db)

        # Hardcoded configurations
        self.file_type_filter = 'commentary'
        self.expected_table_key = 'table_0'

        # Expected column names from Word document tables
        self.quarter_column = 'Quarter'
        self.year_column = 'Year'
        self.commentary_column = 'Commentary'

        # Output column configuration
        self.output_columns = ['file_id', 'company_id', 'quarter', 'commentary']
        self.file_id_column = 'id_x'  # Column name after database merge

    def _format_quarter(self, row: pd.Series) -> Optional[str]:
        """Combine Quarter and Year columns into quarter string."""
        try:
            return f"{row[self.quarter_column]} {row[self.year_column]}"
        except:
            return None

    def _process_single_file(self, file_row: pd.Series) -> Optional[pd.DataFrame]:
        """Process a single Word document's commentary table."""
        try:
            # Read Word document tables
            tables_data = self.extractor.read_document(file_row['path'])

            # Validate table structure
            if len(tables_data.keys()) == 0:
                return None
            if len(tables_data.keys()) > 1:
                return None

            # Extract the single table
            table_df = tables_data.get(self.expected_table_key)
            if table_df is None:
                return None

            # Add file metadata
            table_df = table_df.copy()
            table_df['file_id'] = file_row[self.file_id_column]
            table_df['company_id'] = file_row['company_id']

            return table_df

        except Exception:
            return None

    def _post_process_combined_data(self, combined_df: pd.DataFrame) -> pd.DataFrame:
        """Format quarter field and clean commentary text."""
        # Format quarter field
        combined_df['quarter'] = combined_df.apply(self._format_quarter, axis=1)

        # Clean commentary text
        combined_df['commentary'] = combined_df[self.commentary_column].str.strip()

        # Select final columns
        final_df = combined_df[self.output_columns].copy()
        return final_df

    def transform_commentary(self) -> Tuple[pd.DataFrame, List[str]]:
        """Transform all commentary tables from Word documents."""
        files_df = self._get_files_for_processing(self.file_type_filter)
        return self._batch_process_files(files_df)
