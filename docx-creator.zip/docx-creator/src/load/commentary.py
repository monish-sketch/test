"""Loader for commentary table"""
from typing import Optional

import pandas as pd

from load.base import BaseSupabaseLoader
from transform.commentary import CommentaryTransformer
from google_drive.extractor import GoogleDriveExtractor
from utils.logging import get_logger

logger = get_logger(__name__)


class CommentaryLoader(BaseSupabaseLoader):
    """Loader for commentary data to Supabase"""

    def __init__(self, extractor: Optional[GoogleDriveExtractor] = None):
        super().__init__(extractor)
        self.transformer = CommentaryTransformer(self.extractor, self.db)

    @property
    def table_name(self) -> str:
        return "commentary"

    def _get_df_to_upload(self, *args) -> pd.DataFrame:
        """Transform commentary data and prepare for upload

        Returns:
            pd.DataFrame: Processed DataFrame ready for database insertion
        """
        logger.info(f"Starting transformation for {self.table_name}")

        result = self.transformer.transform_commentary()
        transformed_df = self._handle_transform_result(result)

        if not transformed_df.empty:
            logger.info(f"Transformed {len(transformed_df)} records for upload to {self.table_name}")

        return transformed_df
