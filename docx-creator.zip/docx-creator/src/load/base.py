"""Base class for Supabase data loaders"""
from abc import ABC, abstractmethod
from typing import Optional

import pandas as pd

from db.db import SupabaseDB
from google_drive.extractor import GoogleDriveExtractor
from utils.logging import get_logger

logger = get_logger(__name__)


class BaseSupabaseLoader(ABC):
    """Base class for loading data to Supabase database"""

    @property
    @abstractmethod
    def table_name(self) -> str:
        """Name of table in database"""

    def __init__(self, extractor: Optional[GoogleDriveExtractor] = None):
        self.db = SupabaseDB()
        self.extractor = extractor or GoogleDriveExtractor()

    @abstractmethod
    def _get_df_to_upload(self, *args) -> pd.DataFrame:
        """Process and return DataFrame to upload to database

        Args:
            *args: Arguments needed to generate the DataFrame

        Returns:
            pd.DataFrame: Processed DataFrame ready for database insertion
        """

    def load(self, *args) -> None:
        """Load data to database

        Args:
            *args: Arguments passed to _get_df_to_upload
        """
        logger.info(f"Starting load process for table: {self.table_name}")

        try:
            df_to_upload = self._get_df_to_upload(*args)

            if df_to_upload.empty:
                logger.warning(f"No data to upload for table: {self.table_name}")
                return

            logger.info(f"Uploading {len(df_to_upload)} records to {self.table_name}")
            self.db.insert_records(df_to_upload, self.table_name)
            logger.info(f"Successfully loaded {len(df_to_upload)} records to {self.table_name}")

        except Exception as e:
            logger.error(f"Failed to load data to {self.table_name}: {str(e)}")
            raise

    def _handle_transform_result(self, result) -> pd.DataFrame:
        """Handle transformation result with consistent error logging

        Args:
            result: Either DataFrame or (DataFrame, List[str]) tuple

        Returns:
            pd.DataFrame: The processed DataFrame
        """
        if isinstance(result, tuple) and len(result) == 2:
            transformed_df, errors = result
            if errors:
                logger.warning(f"Transformation completed with {len(errors)} errors")
                for error in errors[:5]:  # Log first 5 errors
                    logger.warning(f"Transform error: {error}")
        else:
            transformed_df = result

        if transformed_df.empty:
            logger.warning("No data returned from transformer")

        return transformed_df
