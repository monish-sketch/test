"""Loader for files table"""
from typing import Optional

import pandas as pd

from load.base import BaseSupabaseLoader
from transform.files import FileListTransformer
from google_drive.extractor import GoogleDriveExtractor
from utils.logging import get_logger

logger = get_logger(__name__)


class FilesLoader(BaseSupabaseLoader):
    """Loader for files data to Supabase"""

    def __init__(self, extractor: Optional[GoogleDriveExtractor] = None):
        super().__init__(extractor)
        self.transformer = FileListTransformer(self.extractor, self.db)

    @property
    def table_name(self) -> str:
        return "files"

    def _get_df_to_upload(self, folder_id: str, recursive: bool = True) -> pd.DataFrame:
        """Transform files list data and prepare for upload

        Args:
            folder_id: Google Drive folder ID to process
            recursive: Whether to process folders recursively

        Returns:
            pd.DataFrame: Processed DataFrame ready for database insertion
        """
        logger.info(f"Starting transformation for {self.table_name} from folder: {folder_id}")

        result = self.transformer.transform_files_list(folder_id, recursive)
        transformed_df = self._handle_transform_result(result)

        if not transformed_df.empty:
            logger.info(f"Transformed {len(transformed_df)} records for upload to {self.table_name}")

        return transformed_df
