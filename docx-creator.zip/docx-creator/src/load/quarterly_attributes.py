"""Loader for quarterly_attributes table"""
from typing import Optional

import pandas as pd

from load.base import BaseSupabaseLoader
from transform.quarterly_attribute import QuarterlyAttributeTransformer
from google_drive.extractor import GoogleDriveExtractor
from utils.logging import get_logger

logger = get_logger(__name__)


class QuarterlyAttributesLoader(BaseSupabaseLoader):
    """Loader for quarterly_attributes data to Supabase"""

    def __init__(self, extractor: Optional[GoogleDriveExtractor] = None):
        super().__init__(extractor)
        self.transformer = QuarterlyAttributeTransformer(self.extractor, self.db)

    @property
    def table_name(self) -> str:
        return "quarterly_attributes"

    def _get_df_to_upload(self, *args) -> pd.DataFrame:
        """Transform quarterly attributes data and prepare for upload

        Returns:
            pd.DataFrame: Processed DataFrame ready for database insertion
        """
        logger.info(f"Starting transformation for {self.table_name}")

        result = self.transformer.transform_quarterly_attributes()
        transformed_df = self._handle_transform_result(result)

        if not transformed_df.empty:
            logger.info(f"Transformed {len(transformed_df)} records for upload to {self.table_name}")

        return transformed_df
