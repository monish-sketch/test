"""
Loaders package for database operations.

This package contains loader classes for inserting transformed data
into the database using the schema models.
"""
