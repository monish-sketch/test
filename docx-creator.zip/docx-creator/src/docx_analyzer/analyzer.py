#!/usr/bin/env python3
"""
Document analyzer for DOCX files.
Analyzes structure, formatting, and footnote implementation.
"""

import os
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Dict, Any, Optional

from lxml import etree

from utils.logging import get_logger

logger = get_logger(__name__)


class DocumentAnalyzer:
    """Comprehensive DOCX document analyzer"""

    def __init__(self, docx_path: str):
        """Initialize analyzer with DOCX file path"""
        self.docx_path = Path(docx_path)
        self.extract_dir = None
        self.analysis_results = {}

        if not self.docx_path.exists():
            raise FileNotFoundError(f"DOCX file not found: {docx_path}")

    def analyze(self, verbose: bool = True) -> Dict[str, Any]:
        """Perform complete analysis of the DOCX document"""
        try:
            # Extract DOCX contents
            self._extract_docx()

            # Perform various analyses
            self.analysis_results = {
                'file_info': self._analyze_file_info(),
                'structure': self._analyze_structure(),
                'footnotes': self._analyze_footnotes(),
                'formatting': self._analyze_formatting(),
                'content_types': self._analyze_content_types(),
                'relationships': self._analyze_relationships()
            }

            if verbose:
                self._print_analysis_results()

            return self.analysis_results

        finally:
            # Clean up temporary files
            self._cleanup()

    def _extract_docx(self):
        """Extract DOCX contents to temporary directory"""
        self.temp_dir = tempfile.mkdtemp(prefix='docx_analysis_')
        self.extract_dir = os.path.join(self.temp_dir, 'contents')

        with zipfile.ZipFile(self.docx_path, 'r') as zip_ref:
            zip_ref.extractall(self.extract_dir)

    def _analyze_file_info(self) -> Dict[str, Any]:
        """Analyze basic file information"""
        file_info = {
            'filename': self.docx_path.name,
            'size_bytes': self.docx_path.stat().st_size,
            'size_mb': round(self.docx_path.stat().st_size / 1024 / 1024, 2)
        }

        # Check modification time
        try:
            file_info['modified'] = self.docx_path.stat().st_mtime
        except:
            file_info['modified'] = 'Unknown'

        return file_info

    def _analyze_structure(self) -> Dict[str, Any]:
        """Analyze DOCX internal structure"""
        structure = {
            'folders': [],
            'files': [],
            'total_files': 0
        }

        for root, dirs, files in os.walk(self.extract_dir):
            rel_path = os.path.relpath(root, self.extract_dir)
            if rel_path != '.':
                structure['folders'].append(rel_path)

            for file in files:
                file_path = os.path.join(rel_path, file) if rel_path != '.' else file
                structure['files'].append(file_path)
                structure['total_files'] += 1

        return structure

    def _analyze_footnotes(self) -> Dict[str, Any]:
        """Analyze footnote implementation"""
        footnotes_analysis = {
            'has_footnotes_xml': False,
            'footnote_count': 0,
            'footnote_types': [],
            'footnote_references': [],
            'footnote_formatting': {}
        }

        # Check for footnotes.xml
        footnotes_path = os.path.join(self.extract_dir, 'word', 'footnotes.xml')
        if os.path.exists(footnotes_path):
            footnotes_analysis['has_footnotes_xml'] = True

            try:
                # Parse footnotes.xml
                tree = etree.parse(footnotes_path)
                root = tree.getroot()

                # Find all footnote elements
                footnotes = root.findall('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}footnote')
                footnotes_analysis['footnote_count'] = len(footnotes)

                for footnote in footnotes:
                    footnote_id = footnote.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}id')
                    footnote_type = footnote.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}type')

                    footnote_info = {
                        'id': footnote_id,
                        'type': footnote_type or 'normal',
                    }

                    # Extract formatting from first run
                    first_run = footnote.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}r')
                    if first_run is not None:
                        formatting = self._extract_run_formatting(first_run)
                        footnote_info['formatting'] = formatting

                    footnotes_analysis['footnote_types'].append(footnote_info)

            except Exception as e:
                footnotes_analysis['error'] = str(e)

        # Check for footnote references in document.xml
        doc_path = os.path.join(self.extract_dir, 'word', 'document.xml')
        if os.path.exists(doc_path):
            try:
                tree = etree.parse(doc_path)
                root = tree.getroot()

                footnote_refs = root.findall('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}footnoteReference')

                for ref in footnote_refs:
                    ref_id = ref.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}id')
                    parent_run = ref.getparent()

                    ref_info = {'id': ref_id}
                    if parent_run is not None:
                        ref_info['formatting'] = self._extract_run_formatting(parent_run)

                    footnotes_analysis['footnote_references'].append(ref_info)

            except Exception as e:
                footnotes_analysis['doc_analysis_error'] = str(e)

        return footnotes_analysis

    def _extract_run_formatting(self, run_element) -> Dict[str, Any]:
        """Extract formatting information from a run element"""
        formatting = {}

        # Get run properties
        rPr = run_element.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}rPr')
        if rPr is not None:
            # Font
            rFonts = rPr.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}rFonts')
            if rFonts is not None:
                formatting['font_ascii'] = rFonts.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}ascii')
                formatting['font_hAnsi'] = rFonts.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}hAnsi')

            # Size
            sz = rPr.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}sz')
            if sz is not None:
                size_val = sz.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')
                formatting['size_halfpts'] = size_val
                formatting['size_pts'] = int(size_val) / 2 if size_val else None

            # Vertical alignment (superscript/subscript)
            vertAlign = rPr.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}vertAlign')
            if vertAlign is not None:
                formatting['vertical_align'] = vertAlign.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')

            # Style
            rStyle = rPr.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}rStyle')
            if rStyle is not None:
                formatting['style'] = rStyle.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')

            # Color
            color = rPr.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}color')
            if color is not None:
                formatting['color'] = color.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val')

            # Italic
            italic = rPr.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}i')
            if italic is not None:
                formatting['italic'] = True

            # Bold
            bold = rPr.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}b')
            if bold is not None:
                formatting['bold'] = True

        return formatting

    def _analyze_formatting(self) -> Dict[str, Any]:
        """Analyze document formatting and styles"""
        formatting = {
            'has_styles_xml': False,
            'style_count': 0,
            'default_fonts': {}
        }

        # Check styles.xml
        styles_path = os.path.join(self.extract_dir, 'word', 'styles.xml')
        if os.path.exists(styles_path):
            formatting['has_styles_xml'] = True

            try:
                tree = etree.parse(styles_path)
                root = tree.getroot()

                styles = root.findall('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}style')
                formatting['style_count'] = len(styles)

                # Look for default font information
                doc_defaults = root.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}docDefaults')
                if doc_defaults is not None:
                    default_run_props = doc_defaults.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}rPrDefault')
                    if default_run_props is not None:
                        rFonts = default_run_props.find('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}rFonts')
                        if rFonts is not None:
                            formatting['default_fonts']['ascii'] = rFonts.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}ascii')
                            formatting['default_fonts']['hAnsi'] = rFonts.get('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}hAnsi')

            except Exception as e:
                formatting['styles_error'] = str(e)

        return formatting

    def _analyze_content_types(self) -> Dict[str, Any]:
        """Analyze content types and parts"""
        content_types = {
            'has_content_types': False,
            'parts': []
        }

        content_types_path = os.path.join(self.extract_dir, '[Content_Types].xml')
        if os.path.exists(content_types_path):
            content_types['has_content_types'] = True

            try:
                tree = etree.parse(content_types_path)
                root = tree.getroot()

                overrides = root.findall('.//{http://schemas.openxmlformats.org/package/2006/content-types}Override')
                for override in overrides:
                    part_name = override.get('PartName')
                    content_type = override.get('ContentType')
                    content_types['parts'].append({
                        'part_name': part_name,
                        'content_type': content_type
                    })

            except Exception as e:
                content_types['error'] = str(e)

        return content_types

    def _analyze_relationships(self) -> Dict[str, Any]:
        """Analyze document relationships"""
        relationships = {
            'document_rels': [],
            'has_footnotes_rel': False
        }

        rels_path = os.path.join(self.extract_dir, 'word', '_rels', 'document.xml.rels')
        if os.path.exists(rels_path):
            try:
                tree = etree.parse(rels_path)
                root = tree.getroot()

                rels = root.findall('.//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship')
                for rel in rels:
                    rel_id = rel.get('Id')
                    rel_type = rel.get('Type')
                    target = rel.get('Target')

                    relationships['document_rels'].append({
                        'id': rel_id,
                        'type': rel_type,
                        'target': target
                    })

                    if 'footnotes' in rel_type.lower():
                        relationships['has_footnotes_rel'] = True

            except Exception as e:
                relationships['error'] = str(e)

        return relationships

    def _print_analysis_results(self):
        """Print formatted analysis results"""
        logger.info(f"\n📊 DOCX Analysis Report: {self.docx_path.name}")
        logger.info("=" * 60)

        # File Info
        file_info = self.analysis_results['file_info']
        logger.info(f"\n📄 File Information:")
        logger.info(f"  Size: {file_info['size_mb']} MB ({file_info['size_bytes']:,} bytes)")

        # Structure
        structure = self.analysis_results['structure']
        logger.info(f"\n🏗️  Document Structure:")
        logger.info(f"  Total files: {structure['total_files']}")
        logger.info(f"  Folders: {len(structure['folders'])}")

        # Footnotes Analysis
        footnotes = self.analysis_results['footnotes']
        logger.info(f"\n📝 Footnotes Analysis:")
        logger.info(f"  Has footnotes.xml: {'✅ Yes' if footnotes['has_footnotes_xml'] else '❌ No'}")

        if footnotes['has_footnotes_xml']:
            logger.info(f"  Footnote count: {footnotes['footnote_count']}")
            logger.info(f"  Reference count: {len(footnotes['footnote_references'])}")

            # Show footnote formatting details
            if footnotes['footnote_references']:
                logger.info(f"\n  📋 Footnote Reference Formatting:")
                for i, ref in enumerate(footnotes['footnote_references'][:3]):  # Show first 3
                    logger.info(f"    Reference {i+1} (ID: {ref['id']}):")
                    formatting = ref.get('formatting', {})
                    if formatting.get('font_ascii'):
                        logger.info(f"      Font: {formatting['font_ascii']}")
                    if formatting.get('size_pts'):
                        logger.info(f"      Size: {formatting['size_pts']}pt")
                    if formatting.get('vertical_align'):
                        logger.info(f"      Alignment: {formatting['vertical_align']}")
                    if formatting.get('color'):
                        logger.info(f"      Color: #{formatting['color']}")

            # Show minimal footnote content formatting
            normal_footnotes = [f for f in footnotes['footnote_types'] if f.get('type') == 'normal' or f.get('type') is None]
            if normal_footnotes:
                formatting = normal_footnotes[0].get('formatting', {})
                logger.info(f"\n  📄 Footnote Content Formatting (first):")
                font = formatting.get('font_ascii')
                size = formatting.get('size_pts')
                italic = formatting.get('italic')
                color = formatting.get('color')
                details = []
                if font:
                    details.append(f"Font: {font}")
                if size:
                    details.append(f"Size: {size}pt")
                if italic:
                    details.append("Style: Italic")
                if color:
                    details.append(f"Color: #{color}")
                if details:
                    logger.info("    " + ", ".join(details))

        # Relationships
        relationships = self.analysis_results['relationships']
        logger.info(f"\n🔗 Document Relationships:")
        logger.info(f"  Has footnotes relationship: {'✅ Yes' if relationships['has_footnotes_rel'] else '❌ No'}")
        logger.info(f"  Total relationships: {len(relationships['document_rels'])}")

        # Content Types
        content_types = self.analysis_results['content_types']
        footnotes_content_type = any('footnotes' in part['content_type'].lower()
                                   for part in content_types.get('parts', []))
        logger.info(f"  Footnotes in content types: {'✅ Yes' if footnotes_content_type else '❌ No'}")

        logger.info(f"\n" + "=" * 60)
        logger.info("✅ Analysis complete!")

    def export_formatting_template(self) -> Optional[Dict[str, Any]]:
        """Export footnote formatting as a template for replication"""
        footnotes = self.analysis_results.get('footnotes', {})
        if not footnotes.get('has_footnotes_xml'):
            return None

        template = {
            'footnote_references': {},
            'footnote_content': {}
        }

        # Extract reference formatting
        if footnotes.get('footnote_references'):
            ref_formatting = footnotes['footnote_references'][0].get('formatting', {})
            template['footnote_references'] = {
                'font': ref_formatting.get('font_ascii', 'Arial'),
                'size_pts': ref_formatting.get('size_pts', 10),
                'vertical_align': ref_formatting.get('vertical_align', 'superscript'),
                'color': ref_formatting.get('color', '000000')
            }

        # Extract content formatting
        normal_footnotes = [f for f in footnotes.get('footnote_types', [])
                          if f.get('type') == 'normal' or f.get('type') is None]
        if normal_footnotes:
            content_formatting = normal_footnotes[0].get('formatting', {})
            template['footnote_content'] = {
                'font': content_formatting.get('font_ascii', 'Arial'),
                'size_pts': content_formatting.get('size_pts', 8),
                'italic': content_formatting.get('italic', False),
                'color': content_formatting.get('color', '000000')
            }

        return template

    def _cleanup(self):
        """Clean up temporary files"""
        if hasattr(self, 'temp_dir') and os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
