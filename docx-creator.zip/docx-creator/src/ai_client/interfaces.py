"""
Abstract interfaces for AI generators.

Provides base interfaces that can be extended for different AI providers
or specialized use cases while maintaining consistent API contracts.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Type, TypeVar, Union
from pydantic import BaseModel

T = TypeVar('T', bound=BaseModel)


class AIGenerator(ABC):
    """Abstract base class for general AI text generation."""
    
    @abstractmethod
    def generate(
        self, 
        prompt: str, 
        system_prompt: Optional[str] = None,
        **kwargs
    ) -> str:
        """
        Generate text response from a prompt.
        
        Args:
            prompt: The user prompt
            system_prompt: Optional system message
            **kwargs: Additional generation parameters
            
        Returns:
            Generated text response
        """
        pass
    
    @abstractmethod
    def generate_with_context(
        self,
        messages: List[Dict[str, str]],
        **kwargs
    ) -> str:
        """
        Generate response with conversation context.
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            **kwargs: Additional generation parameters
            
        Returns:
            Generated text response
        """
        pass


class StructuredAIGenerator(ABC):
    """Abstract base class for structured AI response generation."""
    
    @abstractmethod
    def generate_structured(
        self, 
        prompt: str,
        response_model: Type[T],
        system_prompt: Optional[str] = None,
        **kwargs
    ) -> T:
        """
        Generate structured response using Pydantic model.
        
        Args:
            prompt: The user prompt
            response_model: Pydantic model class for response structure
            system_prompt: Optional system message
            **kwargs: Additional generation parameters
            
        Returns:
            Instantiated Pydantic model with generated data
        """
        pass
    
    @abstractmethod
    def generate_structured_with_context(
        self,
        messages: List[Dict[str, str]],
        response_model: Type[T],
        **kwargs
    ) -> T:
        """
        Generate structured response with conversation context.
        
        Args:
            messages: List of message dicts with 'role' and 'content'  
            response_model: Pydantic model class for response structure
            **kwargs: Additional generation parameters
            
        Returns:
            Instantiated Pydantic model with generated data
        """
        pass


class ConfigurableAIGenerator(ABC):
    """Extended interface for generators with configurable parameters."""
    
    @abstractmethod
    def update_config(self, **config_updates) -> None:
        """Update generator configuration parameters."""
        pass
    
    @abstractmethod
    def get_config(self) -> Dict[str, Any]:
        """Get current generator configuration."""
        pass
    
    @abstractmethod
    def reset_config(self) -> None:
        """Reset configuration to defaults."""
        pass