"""
High-level generator classes for text and structured AI responses.

Provides convenient interfaces for common AI generation tasks while
implementing the abstract interfaces defined in interfaces.py.
"""

from typing import Any, Dict, List, Optional, Type, TypeVar
from pydantic import BaseModel

from ai_client.interfaces import AIGenerator, StructuredAIGenerator, ConfigurableAIGenerator
from ai_client.client import AiClient
from ai_client.models import GenerationConfig, StructuredResponseConfig, ConversationContext
from utils.logging import get_logger

T = TypeVar('T', bound=BaseModel)
logger = get_logger(__name__)


class TextGenerator(AIGenerator, ConfigurableAIGenerator):
    """
    High-level interface for general text generation.

    Provides simple methods for generating text responses with optional
    conversation context and configurable parameters.
    """

    def __init__(
        self,
        client: Optional[AiClient] = None,
        config: Optional[GenerationConfig] = None
    ):
        """
        Initialize text generator.

        Args:
            client: AI client instance (will create default if not provided)
            config: Generation configuration
        """
        self.client = client or AiClient(config=config)
        self.default_config = config or GenerationConfig()
        logger.debug("TextGenerator initialized")

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs
    ) -> str:
        """
        Generate text response from a prompt.

        Args:
            prompt: The user prompt
            system_prompt: Optional system message to guide behavior
            **kwargs: Additional generation parameters (temperature, max_tokens, etc.)

        Returns:
            Generated text response
        """
        messages = []

        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})

        messages.append({"role": "user", "content": prompt})

        logger.debug(f"Generating text response for prompt: {prompt[:100]}...")

        return self.client.generate_text(messages, **kwargs)

    def generate_with_context(
        self,
        messages: List[Dict[str, str]],
        **kwargs
    ) -> str:
        """
        Generate response with conversation context.

        Args:
            messages: List of message dicts with 'role' and 'content'
            **kwargs: Additional generation parameters

        Returns:
            Generated text response
        """
        logger.debug(f"Generating text with context ({len(messages)} messages)")

        return self.client.generate_text(messages, **kwargs)

    def chat(
        self,
        message: str,
        context: Optional[ConversationContext] = None,
        system_prompt: Optional[str] = None,
        **kwargs
    ) -> tuple[str, ConversationContext]:
        """
        Have a conversation with the AI, maintaining context.

        Args:
            message: User message
            context: Existing conversation context (will create new if not provided)
            system_prompt: System prompt to set behavior
            **kwargs: Additional generation parameters

        Returns:
            Tuple of (AI response, updated context)
        """
        if context is None:
            context = ConversationContext()

        if system_prompt and not any(msg.role == "system" for msg in context.messages):
            context.add_message("system", system_prompt)

        context.add_message("user", message)

        response = self.client.generate_text(context.to_openai_format(), **kwargs)

        context.add_message("assistant", response)

        return response, context

    def update_config(self, **config_updates) -> None:
        """Update generator configuration parameters."""
        self.client.update_config(**config_updates)

        # Update local config as well
        for key, value in config_updates.items():
            if hasattr(self.default_config, key):
                setattr(self.default_config, key, value)

    def get_config(self) -> Dict[str, Any]:
        """Get current generator configuration."""
        return self.default_config.model_dump()

    def reset_config(self) -> None:
        """Reset configuration to defaults."""
        self.default_config = GenerationConfig()
        self.client.config = self.default_config


class StructuredGenerator(StructuredAIGenerator, ConfigurableAIGenerator):
    """
    High-level interface for structured response generation.

    Provides type-safe generation of structured data using Pydantic models
    with automatic JSON Schema validation.
    """

    def __init__(
        self,
        client: Optional[AiClient] = None,
        config: Optional[GenerationConfig] = None,
        structured_config: Optional[StructuredResponseConfig] = None
    ):
        """
        Initialize structured generator.

        Args:
            client: AI client instance
            config: Generation configuration
            structured_config: Structured response configuration
        """
        self.client = client or AiClient(config=config)
        self.default_config = config or GenerationConfig()
        self.structured_config = structured_config or StructuredResponseConfig()
        logger.debug("StructuredGenerator initialized")

    def generate_structured(
        self,
        prompt: str,
        response_model: Type[T],
        system_prompt: Optional[str] = None,
        **kwargs
    ) -> T:
        """
        Generate structured response using Pydantic model.

        Args:
            prompt: The user prompt
            response_model: Pydantic model class for response structure
            system_prompt: Optional system message
            **kwargs: Additional generation parameters

        Returns:
            Instantiated Pydantic model with generated data
        """
        messages = []

        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})

        messages.append({"role": "user", "content": prompt})

        logger.debug(f"Generating structured response for model: {response_model.__name__}")

        return self.client.generate_structured(
            messages,
            response_model,
            self.structured_config,
            **kwargs
        )

    def generate_structured_with_context(
        self,
        messages: List[Dict[str, str]],
        response_model: Type[T],
        **kwargs
    ) -> T:
        """
        Generate structured response with conversation context.

        Args:
            messages: List of message dicts with 'role' and 'content'
            response_model: Pydantic model class for response structure
            **kwargs: Additional generation parameters

        Returns:
            Instantiated Pydantic model with generated data
        """
        logger.debug(f"Generating structured response with context for model: {response_model.__name__}")

        return self.client.generate_structured(
            messages,
            response_model,
            self.structured_config,
            **kwargs
        )

    def extract_data(
        self,
        text: str,
        response_model: Type[T],
        extraction_prompt: Optional[str] = None,
        **kwargs
    ) -> T:
        """
        Extract structured data from unstructured text.

        Args:
            text: The text to extract data from
            response_model: Pydantic model for extracted data structure
            extraction_prompt: Custom extraction instructions
            **kwargs: Additional generation parameters

        Returns:
            Instantiated Pydantic model with extracted data
        """
        if extraction_prompt is None:
            extraction_prompt = (
                f"Extract and structure the relevant information from the following text "
                f"according to the required format. Only include information that is "
                f"explicitly stated or can be reasonably inferred from the text."
            )

        prompt = f"{extraction_prompt}\n\nText to extract from:\n{text}"

        return self.generate_structured(prompt, response_model, **kwargs)

    def update_config(self, **config_updates) -> None:
        """Update generator configuration parameters."""
        self.client.update_config(**config_updates)

        # Update local configs
        for key, value in config_updates.items():
            if hasattr(self.default_config, key):
                setattr(self.default_config, key, value)
            elif hasattr(self.structured_config, key):
                setattr(self.structured_config, key, value)

    def get_config(self) -> Dict[str, Any]:
        """Get current generator configuration."""
        return {
            **self.default_config.model_dump(),
            **self.structured_config.model_dump()
        }

    def reset_config(self) -> None:
        """Reset configuration to defaults."""
        self.default_config = GenerationConfig()
        self.structured_config = StructuredResponseConfig()
        self.client.config = self.default_config


class UnifiedGenerator(AIGenerator, StructuredAIGenerator, ConfigurableAIGenerator):
    """
    Unified generator that combines both text and structured generation capabilities.

    Provides a single interface for all generation needs with automatic
    routing based on whether a response model is provided.
    """

    def __init__(
        self,
        client: Optional[AiClient] = None,
        config: Optional[GenerationConfig] = None,
        structured_config: Optional[StructuredResponseConfig] = None
    ):
        """Initialize unified generator."""
        self.text_generator = TextGenerator(client, config)
        self.structured_generator = StructuredGenerator(client, config, structured_config)
        logger.debug("UnifiedGenerator initialized")

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs
    ) -> str:
        """Generate text response."""
        return self.text_generator.generate(prompt, system_prompt, **kwargs)

    def generate_with_context(
        self,
        messages: List[Dict[str, str]],
        **kwargs
    ) -> str:
        """Generate response with context."""
        return self.text_generator.generate_with_context(messages, **kwargs)

    def generate_structured(
        self,
        prompt: str,
        response_model: Type[T],
        system_prompt: Optional[str] = None,
        **kwargs
    ) -> T:
        """Generate structured response."""
        return self.structured_generator.generate_structured(
            prompt, response_model, system_prompt, **kwargs
        )

    def generate_structured_with_context(
        self,
        messages: List[Dict[str, str]],
        response_model: Type[T],
        **kwargs
    ) -> T:
        """Generate structured response with context."""
        return self.structured_generator.generate_structured_with_context(
            messages, response_model, **kwargs
        )

    def update_config(self, **config_updates) -> None:
        """Update configuration for both generators."""
        self.text_generator.update_config(**config_updates)
        self.structured_generator.update_config(**config_updates)

    def get_config(self) -> Dict[str, Any]:
        """Get current configuration."""
        return self.text_generator.get_config()

    def reset_config(self) -> None:
        """Reset configuration to defaults."""
        self.text_generator.reset_config()
        self.structured_generator.reset_config()