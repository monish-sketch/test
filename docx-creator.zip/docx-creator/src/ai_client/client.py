"""
AI client implementation using OpenAI SDK with OpenRouter backend.

Provides the core client functionality for communicating with AI models,
handling authentication, configuration, and error management.
"""

import os
import json
import time
from typing import Any, Dict, List, Optional, Type, TypeVar
from openai import OpenAI
from pydantic import BaseModel

from ai_client.models import GenerationConfig, StructuredResponseConfig
from utils.logging import get_logger

T = TypeVar('T', bound=BaseModel)
logger = get_logger(__name__)


class AiClient:
    """
    Client for interacting with OpenRouter API using OpenAI SDK.

    Handles authentication, request configuration, and response parsing
    with support for both text and structured outputs.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "openai/gpt-4.1",
        system_prompt: Optional[str] = None,
        config: Optional[GenerationConfig] = None,
        base_url: str = "https://openrouter.ai/api/v1"
    ):
        """
        Initialize AI client.

        Args:
            api_key: OpenRouter API key (will use OPENROUTER_API_KEY env var if not provided)
            model: Model to use for generation (validates format and 'auto')
            system_prompt: Default system prompt for all requests
            config: Generation configuration (model will override config.model if provided)
            base_url: OpenRouter API base URL

        Raises:
            ValueError: If API key missing or model format invalid
        """
        self.api_key = api_key or os.getenv("OPENROUTER_API_KEY")
        if not self.api_key:
            raise ValueError("AI Client requires API key. Set OPENROUTER_API_KEY env var or pass api_key parameter.")

        # Validate and set model
        self._validate_model(model)

        # Create config and override model if provided
        self.config = config or GenerationConfig()
        self.config.model = model

        self.system_prompt = system_prompt

        # Initialize OpenAI client with OpenRouter endpoint
        self.client = OpenAI(
            api_key=self.api_key,
            base_url=base_url,
            default_headers=self._get_default_headers()
        )

        logger.debug(f"AI Client initialized with model: {self.config.model}")
        if self.system_prompt:
            logger.debug(f"System prompt set: {self.system_prompt[:100]}...")

    def _validate_model(self, model: str) -> None:
        """
        Validate model format and special values.

        Args:
            model: Model string to validate

        Raises:
            ValueError: If model format is invalid
        """
        if not model:
            raise ValueError("Model cannot be empty")

        # Allow 'auto' as special case
        if model.lower() == "auto":
            return

        # Validate provider/model format
        if "/" not in model:
            raise ValueError("Model must be in 'provider/model' format (e.g., 'openai/gpt-4.1') or 'auto'")

        provider, model_name = model.split("/", 1)
        if not provider or not model_name:
            raise ValueError("Both provider and model name must be specified (e.g., 'openai/gpt-4.1')")

    def _get_default_headers(self) -> Dict[str, str]:
        """Get default headers for OpenRouter requests."""
        headers = {}

        if self.config.app_name:
            headers["X-Title"] = self.config.app_name

        if self.config.app_url:
            headers["HTTP-Referer"] = self.config.app_url

        return headers

    def _prepare_chat_params(self, **kwargs) -> Dict[str, Any]:
        """Prepare parameters for chat completion."""
        params = {
            "model": kwargs.get("model", self.config.model),
            "temperature": kwargs.get("temperature", self.config.temperature),
            "top_p": kwargs.get("top_p", self.config.top_p),
            "frequency_penalty": kwargs.get("frequency_penalty", self.config.frequency_penalty),
            "presence_penalty": kwargs.get("presence_penalty", self.config.presence_penalty),
            "stream": kwargs.get("stream", self.config.stream),
        }

        # Add optional parameters
        if self.config.max_tokens or kwargs.get("max_tokens"):
            params["max_tokens"] = kwargs.get("max_tokens", self.config.max_tokens)

        # OpenRouter specific routing
        extra_headers = {}
        if self.config.provider or kwargs.get("provider"):
            extra_headers["OpenRouter-Provider"] = kwargs.get("provider", self.config.provider)

        if extra_headers:
            params["extra_headers"] = extra_headers

        return params

    def generate_text(
        self,
        messages: List[Dict[str, str]],
        include_system_prompt: bool = True,
        **kwargs
    ) -> str:
        """
        Generate text response from messages.

        Args:
            messages: List of message dicts with 'role' and 'content'
            include_system_prompt: Whether to prepend default system prompt
            **kwargs: Additional parameters to override config

        Returns:
            Generated text content

        Raises:
            Exception: If API call fails
        """
        start_time = time.time()
        params = self._prepare_chat_params(**kwargs)

        # Prepend system prompt if available and requested
        final_messages = messages.copy()
        if include_system_prompt and self.system_prompt:
            # Check if there's already a system message
            has_system = any(msg.get("role") == "system" for msg in messages)
            if not has_system:
                final_messages.insert(0, {"role": "system", "content": self.system_prompt})

        params["messages"] = final_messages

        try:
            logger.debug(f"Making OpenRouter API call with model: {params['model']}")

            response = self.client.chat.completions.create(**params)

            generation_time = time.time() - start_time
            logger.debug(f"Generated response in {generation_time:.2f}s")

            return response.choices[0].message.content

        except Exception as e:
            logger.error(f"OpenRouter API call failed: {e}")
            raise

    def generate_structured(
        self,
        messages: List[Dict[str, str]],
        response_model: Type[T],
        config: Optional[StructuredResponseConfig] = None,
        include_system_prompt: bool = True,
        **kwargs
    ) -> T:
        """
        Generate structured response using JSON Schema.

        Args:
            messages: List of message dicts with 'role' and 'content'
            response_model: Pydantic model class for response structure
            config: Structured response configuration
            include_system_prompt: Whether to prepend default system prompt
            **kwargs: Additional parameters to override config

        Returns:
            Instantiated Pydantic model with generated data

        Raises:
            Exception: If API call fails or response doesn't match schema
        """
        start_time = time.time()
        config = config or StructuredResponseConfig()

        # Prepend system prompt if available and requested
        final_messages = messages.copy()
        if include_system_prompt and self.system_prompt:
            # Check if there's already a system message
            has_system = any(msg.get("role") == "system" for msg in messages)
            if not has_system:
                final_messages.insert(0, {"role": "system", "content": self.system_prompt})

        # Convert Pydantic model to JSON Schema
        schema = response_model.model_json_schema()

        # Handle OpenAI strict mode requirements
        if config.strict:
            def make_strict_schema(schema_dict):
                """Recursively make schema strict for OpenAI compatibility."""
                if isinstance(schema_dict, dict):
                    # Set additionalProperties to false for all objects
                    if "type" in schema_dict and schema_dict["type"] == "object":
                        schema_dict["additionalProperties"] = False

                    # Remove default values for strict mode
                    if "default" in schema_dict:
                        del schema_dict["default"]

                    # Make all properties required for objects
                    if "properties" in schema_dict:
                        schema_dict["required"] = list(schema_dict["properties"].keys())
                        # Recursively process nested properties
                        for prop_def in schema_dict["properties"].values():
                            make_strict_schema(prop_def)

                    # Process items in arrays
                    if "items" in schema_dict:
                        make_strict_schema(schema_dict["items"])
                        # For arrays in strict mode, ensure items are properly defined
                        if schema_dict.get("type") == "array":
                            # Ensure array items have proper structure
                            if isinstance(schema_dict["items"], dict):
                                if "type" not in schema_dict["items"]:
                                    # If items don't specify type, assume string for simple arrays
                                    schema_dict["items"]["type"] = "string"

                    # Process anyOf, oneOf, allOf
                    for key in ["anyOf", "oneOf", "allOf"]:
                        if key in schema_dict:
                            for sub_schema in schema_dict[key]:
                                make_strict_schema(sub_schema)

            make_strict_schema(schema)

            # Process $defs section (where Pydantic stores nested models)
            if "$defs" in schema:
                for def_name, def_schema in schema["$defs"].items():
                    make_strict_schema(def_schema)

            # Resolve $ref references by inlining them (OpenAI has issues with $ref)
            def resolve_refs(schema_dict, defs):
                """Recursively resolve $ref references by inlining definitions."""
                if isinstance(schema_dict, dict):
                    if "$ref" in schema_dict:
                        # Extract reference path (e.g., "#/$defs/FinancialMetrics")
                        ref_path = schema_dict["$ref"]
                        if ref_path.startswith("#/$defs/"):
                            def_name = ref_path.replace("#/$defs/", "")
                            if def_name in defs:
                                # Replace $ref with inline definition
                                inline_def = defs[def_name].copy()
                                # Keep any additional properties from the original reference
                                for key, value in schema_dict.items():
                                    if key != "$ref":
                                        inline_def[key] = value
                                return resolve_refs(inline_def, defs)
                    else:
                        # Recursively process all dict values
                        for key, value in schema_dict.items():
                            schema_dict[key] = resolve_refs(value, defs)
                elif isinstance(schema_dict, list):
                    # Process list items
                    return [resolve_refs(item, defs) for item in schema_dict]

                return schema_dict

            # Resolve all $ref references if $defs exist
            if "$defs" in schema:
                schema = resolve_refs(schema, schema["$defs"])
                # Remove $defs since we've inlined everything
                del schema["$defs"]

            # Ensure root level has additionalProperties set to false
            schema["additionalProperties"] = False

            # Debug: log the schema structure for troubleshooting
            logger.debug(f"Generated strict schema for {response_model.__name__}: {json.dumps(schema, indent=2)}")

        # Prepare OpenAI structured output format
        response_format = {
            "type": "json_schema",
            "json_schema": {
                "name": response_model.__name__.lower(),
                "strict": config.strict,
                "schema": schema
            }
        }

        # For non-strict mode, we can override additionalProperties at the root level
        if not config.strict:
            response_format["json_schema"]["schema"]["additionalProperties"] = config.additional_properties

        params = self._prepare_chat_params(**kwargs)
        params["messages"] = final_messages
        params["response_format"] = response_format

        max_retries = config.max_retries
        last_error = None

        for attempt in range(max_retries + 1):
            try:
                logger.debug(f"Making structured OpenRouter API call (attempt {attempt + 1})")

                response = self.client.chat.completions.create(**params)
                content = response.choices[0].message.content

                # Parse JSON and validate with Pydantic
                try:
                    data = json.loads(content)
                    result = response_model(**data)

                    generation_time = time.time() - start_time
                    logger.debug(f"Generated structured response in {generation_time:.2f}s")

                    return result

                except (json.JSONDecodeError, ValueError) as parse_error:
                    last_error = parse_error
                    if attempt < max_retries:
                        logger.warning(f"Failed to parse response (attempt {attempt + 1}): {parse_error}")
                        continue
                    else:
                        raise ValueError(f"Failed to parse structured response after {max_retries + 1} attempts: {parse_error}")

            except Exception as api_error:
                last_error = api_error
                if attempt < max_retries:
                    logger.warning(f"API call failed (attempt {attempt + 1}): {api_error}")
                    time.sleep(2 ** attempt)  # Exponential backoff
                    continue
                else:
                    logger.error(f"OpenRouter structured API call failed after {max_retries + 1} attempts: {api_error}")
                    raise

        # This shouldn't be reached, but just in case
        if last_error:
            raise last_error

    def update_config(self, **config_updates) -> None:
        """Update client configuration."""
        for key, value in config_updates.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
                logger.debug(f"Updated config: {key} = {value}")
            else:
                logger.warning(f"Unknown config parameter: {key}")

    def get_available_models(self) -> List[Dict[str, Any]]:
        """
        Get list of available models from OpenRouter.

        Returns:
            List of model information dicts
        """
        try:
            # Note: This would require a separate endpoint call to OpenRouter's models API
            # For now, return commonly used models
            return [
                {"id": "openai/gpt-4o", "name": "GPT-4 Omni", "provider": "openai"},
                {"id": "openai/gpt-4o-mini", "name": "GPT-4 Omni Mini", "provider": "openai"},
                {"id": "anthropic/claude-3-5-sonnet", "name": "Claude 3.5 Sonnet", "provider": "anthropic"},
                {"id": "google/gemini-pro-1.5", "name": "Gemini Pro 1.5", "provider": "google"},
                {"id": "meta-llama/llama-3.1-405b-instruct", "name": "Llama 3.1 405B", "provider": "meta-llama"},
            ]
        except Exception as e:
            logger.error(f"Failed to get available models: {e}")
            return []