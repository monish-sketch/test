"""
AI Client Package for OpenRouter Integration

This package provides a flexible and modular AI client implementation
using OpenRouter as the backend, with support for both general text
generation and structured responses using Pydantic models.

Main components:
- OpenRouterClient: Base client for OpenRouter API communication
- TextGenerator: General text generation with flexible prompting
- StructuredGenerator: Type-safe structured responses with Pydantic
- Abstract interfaces for extensibility
"""

from ai_client.client import AiClient
from ai_client.generators import TextGenerator, StructuredGenerator
from ai_client.interfaces import AIGenerator, StructuredAIGenerator
from ai_client.models import GenerationConfig, StructuredResponse, StructuredResponseConfig

__all__ = [
    "AiClient",
    "TextGenerator",
    "StructuredGenerator",
    "AIGenerator",
    "StructuredAIGenerator",
    "GenerationConfig",
    "StructuredResponse",
    "StructuredResponseConfig"
]