"""
Data models for AI client configuration and responses.

Contains Pydantic models for type-safe configuration management
and structured response handling.
"""

from typing import Any, Dict, List, Optional, Union
from pydantic import BaseModel, Field, validator
from enum import Enum


class ModelProvider(str, Enum):
    """Supported AI model providers."""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"  
    GOOGLE = "google"
    COHERE = "cohere"
    META = "meta-llama"
    MISTRAL = "mistralai"
    AUTO = "auto"  # Let OpenRouter choose


class GenerationConfig(BaseModel):
    """Configuration for AI text generation."""
    
    model: str = Field(default="openai/gpt-4.1", description="Model to use for generation")
    max_tokens: Optional[int] = Field(default=None, description="Maximum tokens to generate")
    temperature: float = Field(default=0.7, ge=0.0, le=2.0, description="Sampling temperature")
    top_p: float = Field(default=1.0, ge=0.0, le=1.0, description="Nucleus sampling parameter")
    frequency_penalty: float = Field(default=0.0, ge=-2.0, le=2.0, description="Frequency penalty")
    presence_penalty: float = Field(default=0.0, ge=-2.0, le=2.0, description="Presence penalty")
    stream: bool = Field(default=False, description="Whether to stream responses")
    
    # OpenRouter specific
    provider: Optional[str] = Field(default=None, description="Preferred provider")
    route: Optional[str] = Field(default="fallback", description="Routing strategy")
    
    # Application metadata
    app_name: Optional[str] = Field(default="docx-creator", description="Application name")
    app_url: Optional[str] = Field(default=None, description="Application URL")
    
    @validator('model')
    def validate_model(cls, v):
        """Ensure model format is correct."""
        if v and "/" not in v and not v.startswith("auto"):
            raise ValueError("Model should be in 'provider/model' format or 'auto'")
        return v


class StructuredResponseConfig(BaseModel):
    """Configuration for structured responses."""
    
    strict: bool = Field(default=True, description="Enable strict JSON schema validation")
    additional_properties: bool = Field(default=False, description="Allow additional properties")
    max_retries: int = Field(default=3, ge=0, description="Max retries for malformed responses")
    retry_delay: float = Field(default=1.0, ge=0.0, description="Delay between retries in seconds")
    

class StructuredResponse(BaseModel):
    """Wrapper for structured AI responses with metadata."""
    
    data: BaseModel = Field(description="The structured response data")
    model_used: str = Field(description="Model that generated the response")
    tokens_used: Optional[int] = Field(default=None, description="Tokens consumed")
    cost: Optional[float] = Field(default=None, description="API cost in USD")
    generation_time: Optional[float] = Field(default=None, description="Generation time in seconds")
    
    class Config:
        arbitrary_types_allowed = True


class ConversationMessage(BaseModel):
    """Single message in a conversation."""
    
    role: str = Field(description="Message role: system, user, or assistant")
    content: str = Field(description="Message content")
    
    @validator('role')
    def validate_role(cls, v):
        """Validate message role."""
        allowed_roles = {"system", "user", "assistant", "tool"}
        if v not in allowed_roles:
            raise ValueError(f"Role must be one of: {allowed_roles}")
        return v


class ConversationContext(BaseModel):
    """Context for multi-turn conversations."""
    
    messages: List[ConversationMessage] = Field(default_factory=list, description="Conversation messages")
    max_history: int = Field(default=20, description="Maximum messages to keep in history")
    
    def add_message(self, role: str, content: str) -> None:
        """Add a message to the conversation."""
        self.messages.append(ConversationMessage(role=role, content=content))
        
        # Trim history if needed (keep system message)
        if len(self.messages) > self.max_history:
            system_msgs = [msg for msg in self.messages if msg.role == "system"]
            recent_msgs = [msg for msg in self.messages if msg.role != "system"][-self.max_history:]
            self.messages = system_msgs + recent_msgs
    
    def to_openai_format(self) -> List[Dict[str, str]]:
        """Convert to OpenAI API format."""
        return [{"role": msg.role, "content": msg.content} for msg in self.messages]