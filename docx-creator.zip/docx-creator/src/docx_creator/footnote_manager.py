#!/usr/bin/env python3
"""
Native Word footnote manager for DOCX Creator.
Handles creation and formatting of Word-native footnotes.
"""

import os
import shutil
import tempfile
import zipfile

from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn, nsdecls
from docx.oxml.shared import OxmlElement
from docx.oxml import parse_xml
from docx.text.run import Run
from lxml import etree

from google_drive.config import OFFICE_MIME_TYPES
from utils.logging import get_logger

logger = get_logger(__name__)


class WordFootnoteManager:
    """Manager for native Word footnotes using XML manipulation"""

    def __init__(self, document: Document):
        """Initialize the footnote manager with a document"""
        self.document = document
        self.footnote_counter = 0
        self._ensure_footnotes_part()

    def _ensure_footnotes_part(self):
        """Ensure the document has a footnotes part"""
        try:
            # Try to access the footnotes part
            footnotes_part = self.document.part.footnotes_part
        except AttributeError:
            # Create footnotes part if it doesn't exist
            self._create_footnotes_part()

    def _create_footnotes_part(self):
        """Create the footnotes part in the document"""
        # Initialize footnotes storage in the document itself
        if not hasattr(self.document, '_footnotes'):
            self.document._footnotes = []

        # Create footnotes XML structure matching the template
        footnotes_xml = f'''<w:footnotes {nsdecls('w')}>
            <w:footnote w:type="separator" w:id="-1">
                <w:p>
                    <w:r>
                        <w:separator/>
                    </w:r>
                </w:p>
            </w:footnote>
            <w:footnote w:type="continuationSeparator" w:id="0">
                <w:p>
                    <w:r>
                        <w:continuationSeparator/>
                    </w:r>
                </w:p>
            </w:footnote>
        </w:footnotes>'''

        # Parse and store the XML element
        try:
            self._footnotes_element = parse_xml(footnotes_xml)
            self._footnotes_part = True  # Mark that we have a footnotes structure
        except Exception as e:
            logger.warning(f"Could not create footnotes structure: {e}")

    def _get_footnotes_part(self):
        """Get or create the footnotes part"""
        # Check if we have created the footnotes structure
        if hasattr(self, '_footnotes_part') and self._footnotes_part:
            return self._footnotes_element if hasattr(self, '_footnotes_element') else None

        # If not found, create it
        self._create_footnotes_part()
        return self._footnotes_element if hasattr(self, '_footnotes_element') else None

    def add_footnote_to_run(self, run: Run, footnote_text: str) -> int:
        """Add a native Word footnote to a run matching template formatting"""
        try:
            self.footnote_counter += 1
            footnote_id = self.footnote_counter

            # Format the run for footnote reference using template formatting
            self._format_footnote_reference_run(run)

            # Create footnote reference element
            footnote_ref = OxmlElement('w:footnoteReference')
            footnote_ref.set(qn('w:id'), str(footnote_id))

            # Add the footnote reference to the run
            run._r.append(footnote_ref)

            # Create the footnote in footnotes.xml
            self._create_footnote_element(footnote_id, footnote_text)

            return footnote_id
        except Exception as e:
            logger.warning(f"Could not add footnote to run: {e}")
            # Fallback: add as superscript text
            run.text = str(self.footnote_counter)
            run.font.superscript = True
            run.font.size = Pt(10)  # Template uses 10pt
            run.font.name = "Lucida Bright"  # Template font
            return footnote_id

    def _format_footnote_reference_run(self, run: Run):
        """Format a run for footnote references to match template exactly"""
        # Set run properties for footnote reference
        rPr = run._r.get_or_add_rPr()

        # Clear any existing properties to start fresh
        rPr.clear()

        # Set font name (Lucida Bright as per template)
        rFonts = OxmlElement('w:rFonts')
        rFonts.set(qn('w:ascii'), 'Lucida Bright')
        rFonts.set(qn('w:hAnsi'), 'Lucida Bright')
        rFonts.set(qn('w:eastAsia'), 'Lucida Bright')
        rFonts.set(qn('w:cs'), 'Lucida Bright')
        rPr.append(rFonts)

        # Set font size (20 half-points = 10pt as per template)
        sz = OxmlElement('w:sz')
        sz.set(qn('w:val'), '20')
        rPr.append(sz)

        # Set font size for complex script
        szCs = OxmlElement('w:szCs')
        szCs.set(qn('w:val'), '20')
        rPr.append(szCs)

        # Set superscript
        vertAlign = OxmlElement('w:vertAlign')
        vertAlign.set(qn('w:val'), 'superscript')
        rPr.append(vertAlign)

        # Set color to black
        color = OxmlElement('w:color')
        color.set(qn('w:val'), '000000')
        rPr.append(color)

    def _create_footnote_element(self, footnote_id: int, footnote_text: str):
        """Create a footnote element matching template formatting"""
        # Get footnotes part
        footnotes_part = self._get_footnotes_part()

        if footnotes_part is None:
            logger.warning(f"No footnotes part available, footnote '{footnote_text[:50]}...' will not be created")
            return

        try:
            # Create footnote element
            footnote = OxmlElement('w:footnote')
            footnote.set(qn('w:id'), str(footnote_id))

            # Create paragraph for footnote text
            p = OxmlElement('w:p')

            # Create paragraph properties matching template
            pPr = OxmlElement('w:pPr')

            # Add paragraph borders (nil borders as per template)
            pBdr = OxmlElement('w:pBdr')
            for border in ['top', 'left', 'bottom', 'right', 'between']:
                border_elem = OxmlElement(f'w:{border}')
                border_elem.set(qn('w:val'), 'nil')
                pBdr.append(border_elem)
            pPr.append(pBdr)

            # Add paragraph run properties
            rPr_para = OxmlElement('w:rPr')

            # Font for paragraph
            rFonts_para = OxmlElement('w:rFonts')
            rFonts_para.set(qn('w:ascii'), 'Lucida Bright')
            rFonts_para.set(qn('w:hAnsi'), 'Lucida Bright')
            rFonts_para.set(qn('w:eastAsia'), 'Lucida Bright')
            rFonts_para.set(qn('w:cs'), 'Lucida Bright')
            rPr_para.append(rFonts_para)

            # Italic
            i_para = OxmlElement('w:i')
            rPr_para.append(i_para)

            # Color
            color_para = OxmlElement('w:color')
            color_para.set(qn('w:val'), '000000')
            rPr_para.append(color_para)

            # Size (16 half-points = 8pt for main content)
            sz_para = OxmlElement('w:sz')
            sz_para.set(qn('w:val'), '16')
            rPr_para.append(sz_para)

            szCs_para = OxmlElement('w:szCs')
            szCs_para.set(qn('w:val'), '16')
            rPr_para.append(szCs_para)

            pPr.append(rPr_para)
            p.append(pPr)

            # Create run for footnote reference mark
            r_ref = OxmlElement('w:r')
            rPr_ref = OxmlElement('w:rPr')
            rStyle_ref = OxmlElement('w:rStyle')
            rStyle_ref.set(qn('w:val'), 'FootnoteReference')
            rPr_ref.append(rStyle_ref)
            r_ref.append(rPr_ref)

            footnoteRef_mark = OxmlElement('w:footnoteRef')
            r_ref.append(footnoteRef_mark)
            p.append(r_ref)

            # Create run for footnote text
            r_text = OxmlElement('w:r')
            rPr_text = OxmlElement('w:rPr')

            # Font for text
            rFonts_text = OxmlElement('w:rFonts')
            rFonts_text.set(qn('w:ascii'), 'Lucida Bright')
            rFonts_text.set(qn('w:hAnsi'), 'Lucida Bright')
            rFonts_text.set(qn('w:eastAsia'), 'Lucida Bright')
            rFonts_text.set(qn('w:cs'), 'Lucida Bright')
            rPr_text.append(rFonts_text)

            # Italic
            i_text = OxmlElement('w:i')
            rPr_text.append(i_text)

            # Color
            color_text = OxmlElement('w:color')
            color_text.set(qn('w:val'), '000000')
            rPr_text.append(color_text)

            # Size
            sz_text = OxmlElement('w:sz')
            sz_text.set(qn('w:val'), '16')
            rPr_text.append(sz_text)

            szCs_text = OxmlElement('w:szCs')
            szCs_text.set(qn('w:val'), '16')
            rPr_text.append(szCs_text)

            r_text.append(rPr_text)

            # Add footnote text with leading space
            t = OxmlElement('w:t')
            t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
            t.text = f" {footnote_text}"
            r_text.append(t)
            p.append(r_text)

            footnote.append(p)

            # Add footnote to footnotes element
            try:
                footnotes_part.append(footnote)
            except Exception as append_error:
                logger.warning(f"Could not append footnote element: {append_error}")

        except Exception as e:
            logger.warning(f"Could not create footnote element: {e}")

    def save_document_with_footnotes(self, doc_path: str):
        """Save document and inject footnotes.xml into the DOCX package"""
        # First save the document normally
        self.document.save(doc_path)

        # If we have footnotes, inject them into the DOCX
        if hasattr(self, '_footnotes_element') and self.footnote_counter > 0:
            try:
                self._inject_footnotes_into_docx(doc_path)
            except Exception as e:
                logger.warning(f"Could not inject footnotes into DOCX: {e}")

    def _inject_footnotes_into_docx(self, docx_path: str):
        """Inject footnotes.xml into an existing DOCX file"""

        # Create footnotes XML content
        footnotes_xml = etree.tostring(self._footnotes_element,
                                     xml_declaration=True,
                                     encoding='UTF-8',
                                     pretty_print=True)

        # Create a temporary directory to work with
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_docx = os.path.join(temp_dir, 'temp.docx')

            # Copy original file to temp location
            shutil.copy2(docx_path, temp_docx)

            # Extract DOCX contents
            extract_dir = os.path.join(temp_dir, 'docx_contents')
            with zipfile.ZipFile(temp_docx, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)

            # Write footnotes.xml
            footnotes_path = os.path.join(extract_dir, 'word', 'footnotes.xml')
            with open(footnotes_path, 'wb') as f:
                f.write(footnotes_xml)

            # Add footnotes relationship to document.xml.rels
            self._add_footnotes_relationship(extract_dir)

            # Update [Content_Types].xml
            self._update_content_types(extract_dir)

            # Recreate the DOCX file
            new_docx = os.path.join(temp_dir, 'new.docx')
            with zipfile.ZipFile(new_docx, 'w', zipfile.ZIP_DEFLATED) as zip_ref:
                for root, dirs, files in os.walk(extract_dir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arc_name = os.path.relpath(file_path, extract_dir)
                        zip_ref.write(file_path, arc_name)

            # Replace original file
            shutil.move(new_docx, docx_path)

    def _add_footnotes_relationship(self, extract_dir: str):
        """Add footnotes relationship to document.xml.rels"""
        rels_path = os.path.join(extract_dir, 'word', '_rels', 'document.xml.rels')

        try:

            # Parse existing relationships
            tree = etree.parse(rels_path)
            root = tree.getroot()

            # Find the highest relationship ID
            max_id = 0
            for rel in root.findall('.//{http://schemas.openxmlformats.org/package/2006/relationships}Relationship'):
                rel_id = rel.get('Id', '')
                if rel_id.startswith('rId'):
                    try:
                        id_num = int(rel_id[3:])
                        max_id = max(max_id, id_num)
                    except ValueError:
                        pass

            # Create footnotes relationship
            footnotes_rel = etree.SubElement(root,
                '{http://schemas.openxmlformats.org/package/2006/relationships}Relationship')
            footnotes_rel.set('Id', f'rId{max_id + 1}')
            footnotes_rel.set('Type', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes')
            footnotes_rel.set('Target', 'footnotes.xml')

            # Save the modified relationships file
            tree.write(rels_path, xml_declaration=True, encoding='UTF-8', pretty_print=True)

        except Exception as e:
            logger.warning(f"Could not add footnotes relationship: {e}")

    def _update_content_types(self, extract_dir: str):
        """Update [Content_Types].xml to include footnotes content type"""
        content_types_path = os.path.join(extract_dir, '[Content_Types].xml')

        try:

            # Parse existing content types
            tree = etree.parse(content_types_path)
            root = tree.getroot()

            # Check if footnotes override already exists
            footnotes_exists = False
            for override in root.findall('.//{http://schemas.openxmlformats.org/package/2006/content-types}Override'):
                if override.get('PartName') == '/word/footnotes.xml':
                    footnotes_exists = True
                    break

            # Add footnotes override if it doesn't exist
            if not footnotes_exists:
                footnotes_override = etree.SubElement(root,
                    '{http://schemas.openxmlformats.org/package/2006/content-types}Override')
                footnotes_override.set('PartName', '/word/footnotes.xml')
                footnotes_override.set('ContentType',
                    OFFICE_MIME_TYPES["word_footnotes"])

            # Save the modified content types file
            tree.write(content_types_path, xml_declaration=True, encoding='UTF-8', pretty_print=True)

        except Exception as e:
            logger.warning(f"Could not update content types: {e}")
