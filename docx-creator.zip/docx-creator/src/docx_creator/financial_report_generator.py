#!/usr/bin/env python3
"""
Financial report document generator for DOCX Creator.
Creates professional financial reports as Word documents.
"""

from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.oxml.ns import qn
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.shared import OxmlElement
from docx.oxml import parse_xml

# Import our new modular structure
from dataclass.final_report.footnote import FootnoteLocation, FootnoteRegistry
from dataclass.final_report.report import FinancialReport
from dataclass.final_report.investment import InvestmentRecord
from dataclass.final_report.capital_table import CapitalTable, CapitalTableRow
from dataclass.final_report.funding import FundingDetails
from dataclass.final_report.financials import FinancialQuarter, CompanyFinancials
from docx_creator.footnote_manager import WordFootnoteManager

# Mock Data Functions
def create_mock_data() -> FinancialReport:
    """Create mock data for the financial report"""

    # Create footnote registry and add footnotes
    footnote_registry = FootnoteRegistry()

    # Add footnotes for investment record
    footnote_registry.add_footnote(
        FootnoteLocation.INVESTMENT_RECORD,
        "cost_of_investment",
        "Represents amount invested in the Company as at June 30, 2025."
    )
    footnote_registry.add_footnote(
        FootnoteLocation.INVESTMENT_RECORD,
        "net_asset_value",
        "Represents carrying value of the Investment in the books of Fireside Ventures as at June 30, 2025 basis External Valuation from Kroll Advisory Private Limited (formerly, Duff and Phelps India Private Limited) as at March 31, 2025 or most recent round valuation prior to June 30, 2025"
    )

    # Add footnote for capital table
    footnote_registry.add_footnote(
        FootnoteLocation.CAPITAL_TABLE,
        "z1_z2_ccps",
        "Represent partly paid up CCPS issued for additional venture debt availed by Company"
    )

    # Investment Record Mock Data
    investment_record = InvestmentRecord()

    # Capital Table Mock Data
    capital_table_rows = [
        CapitalTableRow(
            particulars="Founders",
            equity="10,000",
            series_i_ccps="-",
            series_ii_ccps="-",
            z1_z2_ccps="-",
            total="10,000",
            current_ownership="61.3%",
            fully_diluted="55.2%"
        ),
        CapitalTableRow(
            particulars="Option pool",
            equity="1,802",
            series_i_ccps="-",
            series_ii_ccps="-",
            z1_z2_ccps="-",
            total="1,802",
            current_ownership="-",
            fully_diluted="9.9%"
        ),
        CapitalTableRow(
            particulars="Fireside Ventures",
            equity="10",
            series_i_ccps="-",
            series_ii_ccps="3,954",
            z1_z2_ccps="-",
            total="3,964",
            current_ownership="24.3%",
            fully_diluted="21.9%"
        ),
        CapitalTableRow(
            particulars="Other investors",
            equity="487",
            series_i_ccps="1,765",
            series_ii_ccps="-",
            z1_z2_ccps="102",
            total="2,354",
            current_ownership="14.4%",
            fully_diluted="13%"
        ),
        CapitalTableRow(
            particulars="Total",
            equity="12,299",
            series_i_ccps="1,765",
            series_ii_ccps="3,954",
            z1_z2_ccps="102",
            total="18,120",
            current_ownership="100.0%",
            fully_diluted="100.0%"
        )
    ]

    capital_table = CapitalTable(rows=capital_table_rows)

    # Funding Details Mock Data
    funding_details = FundingDetails()

    # Company Financials Mock Data
    financial_quarters = [
        FinancialQuarter(
            quarter_name="JFM 2024",
            net_revenue="7.0",
            ebitda="-7.2",
            gross_cash="72.0",
            debt_inr_mn="-",
            headcount="5"
        ),
        FinancialQuarter(
            quarter_name="AMJ 2024",
            net_revenue="8.8",
            ebitda="-4.8",
            gross_cash="60.0",
            debt_inr_mn="-",
            headcount="6"
        ),
        FinancialQuarter(
            quarter_name="JAS 2024",
            net_revenue="10.6",
            ebitda="-6.6",
            gross_cash="58.3",
            debt_inr_mn="8.0",
            headcount="7"
        ),
        FinancialQuarter(
            quarter_name="OND 2024",
            net_revenue="13.3",
            ebitda="-12.3",
            gross_cash="55.0",
            debt_inr_mn="19.4",
            headcount="8"
        ),
        FinancialQuarter(
            quarter_name="JFM 2025",
            net_revenue="31.2",
            ebitda="-11.8",
            gross_cash="37.1",
            debt_inr_mn="24.0",
            headcount="10"
        ),
        FinancialQuarter(
            quarter_name="AMJ 2025",
            net_revenue="98.7",
            ebitda="-16.7",
            gross_cash="27.0",
            debt_inr_mn="16.4",
            headcount="14"
        )
    ]

    company_financials = CompanyFinancials(quarters=financial_quarters)

    # Create complete financial report
    financial_report = FinancialReport(
        investment_record=investment_record,
        capital_table=capital_table,
        funding_details=funding_details,
        company_financials=company_financials,
        footnote_registry=footnote_registry
    )

    return financial_report

# Document Formatting Functions
def add_page_number_to_footer(doc, page_number: int) -> None:
    """Add only page number to footer"""
    section = doc.sections[0]
    footer = section.footer

    # Clear any existing paragraphs in footer
    for paragraph in footer.paragraphs:
        p = paragraph._element
        p.getparent().remove(p)

    # Add page number to footer
    page_para = footer.add_paragraph()
    page_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER

    page_run = page_para.add_run(str(page_number))
    page_run.font.size = Pt(10)
    page_run.font.name = "Arial"
    page_run.font.bold = True

def set_cell_background_color(cell, color):
    """Set background color for a table cell"""
    shading_elm = parse_xml(r'<w:shd {} w:fill="{}"/>'.format(
        'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"', color))
    cell._tc.get_or_add_tcPr().append(shading_elm)

def set_cell_border(cell, border_size=4):
    """Set border for a table cell"""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in("w:tcBorders")
    if tcBorders is None:
        tcBorders = OxmlElement('w:tcBorders')
        tcPr.append(tcBorders)

    # Set all borders
    for border_name in ['top', 'left', 'bottom', 'right']:
        border = tcBorders.find(qn(f'w:{border_name}'))
        if border is None:
            border = OxmlElement(f'w:{border_name}')
            tcBorders.append(border)
        border.set(qn('w:val'), 'single')
        border.set(qn('w:sz'), str(border_size))
        border.set(qn('w:color'), '000000')

def format_table_cell(cell, text, bold=False, font_size=9, center_align=False, bg_color=None):
    """Format a table cell with exact styling"""
    cell.text = text

    # Set background color if provided
    if bg_color:
        set_cell_background_color(cell, bg_color)

    # Set borders
    set_cell_border(cell)

    # Format text
    for paragraph in cell.paragraphs:
        if center_align:
            paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        for run in paragraph.runs:
            run.font.size = Pt(font_size)
            run.font.name = "Arial"
            run.font.bold = bold
            run.font.color.rgb = RGBColor(0, 0, 0)

    # Set cell margins
    cell.vertical_alignment = 1  # Center vertically

def create_investment_record_section(doc, investment_record, footnote_registry: FootnoteRegistry, footnote_manager: WordFootnoteManager = None):
    """Create the investment record section exactly as shown - positioned on the right half"""

    # Create a container table for layout positioning
    layout_table = doc.add_table(rows=1, cols=2)
    layout_table.style = None
    layout_table.alignment = WD_TABLE_ALIGNMENT.CENTER

    # Remove borders from layout table
    for row in layout_table.rows:
        for cell in row.cells:
            cell._tc.get_or_add_tcPr().append(parse_xml(r'<w:tcBorders xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/></w:tcBorders>'))

    # Left cell - contains the red circle
    left_cell = layout_table.rows[0].cells[0]
    circle_para = left_cell.paragraphs[0]
    circle_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER

    # Add the red circle bullet and percentage
    circle_run = circle_para.add_run("● 21.9")
    circle_run.font.size = Pt(14)
    circle_run.font.name = "Arial"
    circle_run.font.color.rgb = RGBColor(220, 50, 47)
    circle_run.font.bold = True

    # Right cell - contains the investment record table and INR Mn label
    right_cell = layout_table.rows[0].cells[1]

    # Clear the default paragraph
    right_cell._element.clear_content()

    # Add INR Mn label
    inr_para = right_cell.add_paragraph("(INR Mn)")
    inr_para.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT
    inr_para.paragraph_format.space_after = Pt(6)
    inr_run = inr_para.runs[0]
    inr_run.font.size = Pt(8)
    inr_run.font.name = "Arial"
    inr_run.font.italic = True

    # Create the investment record table inside the right cell
    table = right_cell.add_table(rows=2, cols=3)
    table.style = None
    table.alignment = WD_TABLE_ALIGNMENT.RIGHT

    # Set table width to fit properly
    for row in table.rows:
        for cell in row.cells:
            cell.width = Inches(1.0)

    # Header row with gray background
    header_cells = table.rows[0].cells

    # Get footnote objects for investment record elements
    cost_footnote = footnote_registry.get_footnote_by_element(FootnoteLocation.INVESTMENT_RECORD, "cost_of_investment")
    nav_footnote = footnote_registry.get_footnote_by_element(FootnoteLocation.INVESTMENT_RECORD, "net_asset_value")

    # Create headers with footnote references
    headers = ["Cost of\nInvestment", "Last funding round\nCompany\nValuation", "Net Asset\nValue"]

    for i, header in enumerate(headers):
        # Create paragraph for header cell to allow for footnote formatting
        cell = header_cells[i]
        cell.text = ""  # Clear default text
        para = cell.paragraphs[0]
        para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER

        # Add main header text
        run1 = para.add_run(header)
        run1.font.size = Pt(9)
        run1.font.name = "Arial"
        run1.font.bold = True

        # Add footnote reference if applicable and footnote manager is available
        if footnote_manager:
            if i == 0 and cost_footnote:  # Cost of Investment
                footnote_run = para.add_run()
                footnote_manager.add_footnote_to_run(footnote_run, cost_footnote.text)
            elif i == 2 and nav_footnote:  # Net Asset Value
                footnote_run = para.add_run()
                footnote_manager.add_footnote_to_run(footnote_run, nav_footnote.text)

        # Set cell background
        set_cell_background_color(cell, "E5E5E5")

    # Data row
    data_cells = table.rows[1].cells
    values = [investment_record.cost_of_investment, investment_record.last_funding_valuation, investment_record.net_asset_value]

    for i, value in enumerate(values):
        format_table_cell(data_cells[i], value, font_size=9, center_align=True)

def create_capital_table_section(doc, capital_table, footnote_registry: FootnoteRegistry, footnote_manager: WordFootnoteManager = None):
    """Create the capital table section exactly as shown"""

    table = doc.add_table(rows=6, cols=8)
    table.style = None
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    # Header row
    header_cells = table.rows[0].cells

    # Get footnote for Z1/Z2 CCPS
    z1z2_footnote = footnote_registry.get_footnote_by_element(FootnoteLocation.CAPITAL_TABLE, "z1_z2_ccps")

    # Create headers
    headers = ["Particulars", "Equity", "Series I\nCCPS", "Series II\nCCPS", "Z1/Z2\nCCPS", "Total", "Current\nownership", "Fully\ndiluted"]

    for i, header in enumerate(headers):
        cell = header_cells[i]
        cell.text = ""  # Clear default text
        para = cell.paragraphs[0]
        para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER

        # Add main header text
        run1 = para.add_run(header)
        run1.font.size = Pt(8)
        run1.font.name = "Arial"
        run1.font.bold = True

        # Add footnote reference if applicable
        if footnote_manager and i == 4 and z1z2_footnote:  # Z1/Z2 CCPS column
            footnote_run = para.add_run()
            footnote_manager.add_footnote_to_run(footnote_run, z1z2_footnote.text)

        # Set cell background
        set_cell_background_color(cell, "E5E5E5")

    # Data rows
    for row_idx, row_data in enumerate(capital_table.rows):
        cells = table.rows[row_idx + 1].cells
        values = [
            row_data.particulars,
            row_data.equity,
            row_data.series_i_ccps,
            row_data.series_ii_ccps,
            row_data.z1_z2_ccps,
            row_data.total,
            row_data.current_ownership,
            row_data.fully_diluted
        ]

        is_total_row = row_data.particulars == "Total"

        for i, value in enumerate(values):
            format_table_cell(cells[i], value, bold=is_total_row, font_size=8, center_align=(i > 0))

def create_funding_details_section(doc, funding_details):
    """Create the funding details section exactly as shown"""

    # Add (INR Mn) label
    inr_para = doc.add_paragraph("(INR Mn)")
    inr_para.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
    inr_para.paragraph_format.space_after = Pt(0)
    inr_run = inr_para.runs[0]
    inr_run.font.size = Pt(8)
    inr_run.font.name = "Arial"
    inr_run.font.italic = True

    # Add funding type and date
    funding_para = doc.add_paragraph()
    funding_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    funding_para.paragraph_format.space_before = Pt(6)
    funding_para.paragraph_format.space_after = Pt(6)

    type_run = funding_para.add_run(funding_details.series_type)
    type_run.font.size = Pt(10)
    type_run.font.name = "Arial"
    type_run.font.bold = True

    funding_para.add_run("\n")

    date_run = funding_para.add_run(funding_details.date)
    date_run.font.size = Pt(9)
    date_run.font.name = "Arial"

    # Create funding table
    table = doc.add_table(rows=4, cols=2)
    table.style = None
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    funding_data = [
        ("Pre-Money", funding_details.pre_money),
        ("Total money raised", funding_details.total_money_raised),
        ("Post-Money", funding_details.post_money),
        ("Fireside Ventures", funding_details.fireside_ventures)
    ]

    for i, (label, value) in enumerate(funding_data):
        cells = table.rows[i].cells
        format_table_cell(cells[0], label, font_size=9, center_align=True, bg_color="E5E5E5")
        format_table_cell(cells[1], value, font_size=9, center_align=True)

def create_company_financials_section(doc, company_financials):
    """Create the company financials section exactly as shown"""

    table = doc.add_table(rows=6, cols=7)
    table.style = None
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    # Header row with quarters
    header_cells = table.rows[0].cells
    format_table_cell(header_cells[0], "Quarters", bold=True, font_size=8, center_align=True, bg_color="E5E5E5")

    for i, quarter in enumerate(company_financials.quarters):
        format_table_cell(header_cells[i + 1], quarter.quarter_name, bold=True, font_size=8, center_align=True, bg_color="E5E5E5")

    # Data rows
    metrics = [
        ("Net Revenue (INR Mn)", [q.net_revenue for q in company_financials.quarters]),
        ("EBITDA (INR Mn)", [q.ebitda for q in company_financials.quarters]),
        ("Gross Cash (INR Mn)", [q.gross_cash for q in company_financials.quarters]),
        ("Debt (INR Mn)", [q.debt_inr_mn for q in company_financials.quarters]),
        ("Headcount", [q.headcount for q in company_financials.quarters])
    ]

    for row_idx, (metric, values) in enumerate(metrics):
        cells = table.rows[row_idx + 1].cells
        format_table_cell(cells[0], metric, bold=True, font_size=8, bg_color="E5E5E5")

        for i, value in enumerate(values):
            format_table_cell(cells[i + 1], value, font_size=8, center_align=True)

def create_section_title(doc, title, color_rgb=(220, 50, 47)):
    """Create a section title with red color"""
    para = doc.add_paragraph()
    para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    para.paragraph_format.space_before = Pt(18)
    para.paragraph_format.space_after = Pt(12)

    run = para.add_run(title)
    run.font.size = Pt(12)
    run.font.name = "Arial"
    run.font.bold = True
    run.font.color.rgb = RGBColor(*color_rgb)

def create_financial_report_document(financial_report: FinancialReport) -> tuple:
    """Create the financial report document with native footnotes"""

    doc = Document()

    # Initialize the footnote manager for native footnotes
    footnote_manager = WordFootnoteManager(doc)

    # Set narrow margins but leave more space at bottom for footer
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(0.7)
        section.bottom_margin = Inches(1.2)  # More space for footer
        section.left_margin = Inches(0.7)
        section.right_margin = Inches(0.7)
        section.footer_distance = Inches(0.3)  # Distance from bottom of page to footer

    # Title
    title_para = doc.add_paragraph()
    title_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    title_para.paragraph_format.space_after = Pt(24)

    title_run = title_para.add_run(financial_report.company_name)
    title_run.font.size = Pt(18)
    title_run.font.name = "Arial"
    title_run.font.bold = True
    title_run.font.color.rgb = RGBColor(0, 0, 0)

    # Investment Record Section
    create_section_title(doc, "INVESTMENT RECORD")
    create_investment_record_section(doc, financial_report.investment_record, financial_report.footnote_registry, footnote_manager)

    # Capital Table Section
    create_section_title(doc, "CAPITAL TABLE")
    create_capital_table_section(doc, financial_report.capital_table, financial_report.footnote_registry, footnote_manager)

    # Funding Details Section
    create_section_title(doc, "FUNDING DETAILS")
    create_funding_details_section(doc, financial_report.funding_details)

    # Company Financials Section
    create_section_title(doc, "COMPANY FINANCIALS")
    create_company_financials_section(doc, financial_report.company_financials)

    # Add page number to footer
    add_page_number_to_footer(doc, financial_report.page_number)

    return doc, footnote_manager
