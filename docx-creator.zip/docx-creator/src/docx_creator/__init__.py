"""DOCX Creator - A Python tool for creating nicely formatted Word documents with financial data."""
