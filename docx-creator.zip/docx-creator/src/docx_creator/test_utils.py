#!/usr/bin/env python3
"""
Test utilities for DOCX Creator.
"""

import zipfile
from pathlib import Path
# bool is a built-in type, no need to import


def test_docx_for_footnotes(file_path: str) -> bool:
    """
    Test if a DOCX file contains native footnotes.
    
    Args:
        file_path: Path to the DOCX file
        
    Returns:
        True if the file contains footnotes.xml, False otherwise
    """
    try:
        with zipfile.ZipFile(file_path, 'r') as docx_zip:
            # Check if footnotes.xml exists in the document
            return 'word/footnotes.xml' in docx_zip.namelist()
    except (zipfile.BadZipFile, FileNotFoundError):
        return False
