"""DataFrame utility functions for Excel data processing."""

from typing import Optional
import pandas as pd


def find_next_empty_row(df: pd.DataFrame, row_number: int = 0, end_col: Optional[int] = None) -> Optional[int]:
    """Find the next empty row in the dataframe after the given row number.

    This is commonly used when processing Excel/Google Sheets data to find
    table boundaries by locating empty rows.

    Args:
        df: DataFrame to search in
        row_number: Start searching after this row number (default: 0)
        end_col: Only check columns up to this index (default: all columns)

    Returns:
        Index of the next empty row, or None if no empty row found
    """
    # Limit to specific columns if specified
    if end_col is not None:
        df = df.iloc[:, :end_col]

    # Find first empty row after the specified row number
    for index, row in df.iterrows():
        if index > row_number and row.isnull().all():
            return index
    return None


def remove_identical_adjacent_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Remove columns that are identical to their adjacent column.

    This is useful when Excel files have duplicate columns due to formatting
    or merged cell processing.

    Args:
        df: DataFrame to process

    Returns:
        DataFrame with duplicate adjacent columns removed
    """
    drop_cols = []
    for i in range(len(df.columns) - 1):
        col_i = df.columns[i]
        col_j = df.columns[i + 1]
        if df[col_i].equals(df[col_j]):
            drop_cols.append(col_j)
    return df.drop(columns=drop_cols)
