"""Simple logging utilities for docx-creator."""

import logging
import sys
from pathlib import Path


def setup_logging(level: str = "INFO", log_to_file: bool = False, log_dir: str = "logs") -> None:
    """
    Simple logging setup for the application.

    Args:
        level: Log level ("DEBUG", "INFO", "WARNING", "ERROR")
        log_to_file: Whether to also log to file
        log_dir: Directory for log files (only used if log_to_file=True)
    """
    # Convert string level to logging constant
    numeric_level = getattr(logging, level.upper(), logging.INFO)

    # Basic console formatting
    formatter = logging.Formatter(
        fmt='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%H:%M:%S'
    )

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)

    # Remove existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Add console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    # Add file handler if requested
    if log_to_file:
        Path(log_dir).mkdir(exist_ok=True)
        file_handler = logging.FileHandler(Path(log_dir) / "docx_creator.log")
        file_handler.setLevel(logging.DEBUG)  # File gets all logs
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger for the specified module.

    Args:
        name: Usually pass __name__ here

    Returns:
        Logger instance
    """
    return logging.getLogger(name)


# Convenience function for quick setup
def init_logging(debug: bool = False, file_logging: bool = False) -> logging.Logger:
    """
    Quick logging initialization.

    Args:
        debug: If True, set level to DEBUG, otherwise INFO
        file_logging: Whether to enable file logging

    Returns:
        Root logger
    """
    level = "DEBUG" if debug else "INFO"
    setup_logging(level=level, log_to_file=file_logging)
    return get_logger(__name__)
