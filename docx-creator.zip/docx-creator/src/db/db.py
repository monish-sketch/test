"""Functions to interact with db"""

import datetime
import json
from typing import List

import pandas as pd
import pytz

from sqlalchemy import create_engine, MetaData, Table, and_
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import sessionmaker

from db.config import (
    DEFAULT_SUPABASE_CREDENTIALS_PATH,
    DEFAULT_POOLER_REGION,
    DEFAULT_POOLER_PORT,
    DEFAULT_DATABASE_NAME,
    SUPABASE_POOLER_TEMPLATE,
    DEFAULT_CONNECTION_TYPE,
)
from utils.logging import get_logger

logger = get_logger(__name__)


class PostgreSQLManager:
    """Manage postgresql operations

    `simple_filter` means what can be used in filter_by
    only AND arguments
    """

    def __init__(self, db_uri):
        self.db_uri = db_uri
        self.engine = create_engine(self.db_uri)
        self.conn = self.engine.connect()
        self.metadata_obj = MetaData()
        self.make_session = sessionmaker(bind=self.engine)

    def get_table(self, table_name):
        """Get Table object from table name"""
        return Table(table_name, self.metadata_obj, autoload_with=self.engine)

    @staticmethod
    def time_filter(start_dt, end_dt, column):
        """Get a time filter"""
        filter_expressions = []
        if start_dt is not None:
            filter_expressions.append(column >= start_dt)
        if end_dt is not None:
            filter_expressions.append(column <= end_dt)
        return and_(True, *filter_expressions)

    def get_all_records(
        self,
        table_name: str,
        filter_condition=None,
        simple_filter: dict = None,
        limit: int = 0,
    ) -> pd.DataFrame:
        """Get all records from database"""
        table = self.get_table(table_name)
        with self.make_session() as session:
            query = session.query(table)
            if filter_condition is not None:
                query = query.filter(filter_condition)
            if simple_filter is not None:
                query = query.filter_by(**simple_filter)
            if limit > 0:
                query = query.limit(limit)
            results = query.all()
        logger.info("Returned %d records from %s...", len(results), table_name)
        return pd.DataFrame(results)

    def get_one_record(
        self, table_name: str, filter_condition=None, simple_filter: dict = None
    ):
        """Get one record from database"""
        table = self.get_table(table_name)
        with self.make_session() as session:
            query = session.query(table)
            if filter_condition is not None:
                query = query.filter(filter_condition)
            if simple_filter is not None:
                query = query.filter_by(**simple_filter)
            result = query.one()
        return result

    def get_distinct_column(
        self,
        table_name: str,
        column_name: str,
        filter_condition=None,
        simple_filter: dict = None,
    ):
        """Gets distinct records for a single column"""
        table = self.get_table(table_name)
        with self.make_session() as session:
            query = session.query(table.columns[column_name])
            if filter_condition is not None:
                query = query.filter(filter_condition)
            if simple_filter is not None:
                query = query.filter_by(**simple_filter)
            results = query.distinct().all()
        logger.info(
            "Returned %d %s records from %s...", len(results), column_name, table_name
        )
        return pd.DataFrame(results)[column_name]

    @staticmethod
    def add_table_metadata(df: pd.DataFrame):
        """Add metadata"""
        utc_tz = pytz.timezone("UTC")
        time_now = datetime.datetime.now(tz=utc_tz)
        batch_id = 1  # TODO: Batch Id has to come from the process

        df = df.copy()
        df.loc[:, "created_time"] = time_now
        df.loc[:, "modified_time"] = time_now
        df.loc[:, "created_batch_id"] = batch_id
        df.loc[:, "modified_batch_id"] = batch_id

        return df

    def insert_records(
        self,
        df: pd.DataFrame,
        table_name: str,
        upsert: bool = True,
        add_metadata: bool = True,
        pkey_drop_duplicates: bool = True,
        non_nullable_check: bool = True,
    ) -> None:
        """Insert records into database"""
        table = self.get_table(table_name)
        if add_metadata:
            df = PostgreSQLManager.add_table_metadata(df)

        # Few checks
        if pkey_drop_duplicates:
            pkey_columns = [c.name for c in table.primary_key.columns]
            assert len(df.drop_duplicates(subset=pkey_columns)) == len(
                df
            ), "You are trying to insert duplicate rows."
        if non_nullable_check:
            non_nullable_columns = [c.name for c in table.c if not c.nullable]
            assert len(df.dropna(subset=non_nullable_columns)) == len(
                df
            ), "You are trying to insert nulls in non-nullable columns."

        to_write = df.to_dict(orient="records")
        logger.info("Writing %d records into table...", len(to_write))

        stmt = insert(table).values(to_write)
        if upsert:
            # Credit: https://gist.github.com/bhtucker/c40578a2fb3ca50b324e42ef9dce58e1
            no_update_cols = pkey_columns + ["created_time", "created_batch_id"]
            update_cols = [c.name for c in table.c if c.name not in no_update_cols]
            stmt = stmt.on_conflict_do_update(
                index_elements=table.primary_key.columns,
                set_={k: getattr(stmt.excluded, k) for k in update_cols},
            )

        with self.conn.begin():
            self.conn.execute(stmt)
        logger.info("Write done!")

    def join_columns_from_table(
        self,
        df: pd.DataFrame,
        table_name: str,
        reference_column: str,
        output_columns: List[str],
    ) -> pd.DataFrame:
        """Enrich with columns from another table"""

        db = LocalDB()
        table = db.get_table(table_name)

        if reference_column not in table.columns:
            raise NotImplementedError(f"{reference_column} not found in the table")

        filter_condition = table.columns[reference_column].in_(df[reference_column])
        reference_data = db.get_all_records(
            table_name, filter_condition=filter_condition
        )

        assert len(reference_data.drop_duplicates(subset=[reference_column])) == len(
            reference_data
        ), "This function expects a one-one map"

        columns_to_keep = list(set([reference_column] + output_columns))
        df = pd.merge(
            df, reference_data[columns_to_keep], how="left", on=reference_column
        )
        return df


class LocalDB(PostgreSQLManager):
    """Local DB"""

    def __init__(self):
        super().__init__(
            "postgresql+psycopg2://postgres:aistudio@localhost:5432/postgres"
        )


class SupabaseDB(PostgreSQLManager):
    """Supabase DB Connection"""

    def __init__(self, credentials_path: str = None):
        """
        Initialize Supabase connection using credentials file

        Args:
            credentials_path: Path to JSON file containing Supabase credentials
        """
        if credentials_path is None:
            credentials_path = str(DEFAULT_SUPABASE_CREDENTIALS_PATH)

        # Load Supabase credentials
        with open(credentials_path, "r", encoding="utf-8") as f:
            creds = json.load(f)

        # Extract connection details from Supabase URL
        supabase_url = creds["supabase_url"]
        supabase_key = creds["supabase_key"]

        # Parse the URL to get the project ID and construct PostgreSQL connection string
        # Supabase URLs are typically: https://your-project-id.supabase.co
        if "supabase.co" in supabase_url:
            project_id = supabase_url.split("//")[1].split(".")[0]

            # Construct PostgreSQL connection string for Supabase
            if DEFAULT_CONNECTION_TYPE == "pooler":
                db_uri = SUPABASE_POOLER_TEMPLATE.format(
                    project_id=project_id,
                    supabase_key=supabase_key,
                    pooler_host=f"{DEFAULT_POOLER_REGION}.pooler.supabase.com",
                    port=DEFAULT_POOLER_PORT,
                    db_name=DEFAULT_DATABASE_NAME,
                )
            else:
                db_uri = f"postgresql://postgres:{supabase_key}@db.{project_id}.supabase.co:{DEFAULT_POOLER_PORT}/{DEFAULT_DATABASE_NAME}"

            logger.info(f"Connected to Supabase project: {project_id}")
        else:
            raise ValueError("Invalid Supabase URL format")

        # Initialize parent class with the connection string
        super().__init__(db_uri)


__all__ = ("LocalDB", "SupabaseDB")
