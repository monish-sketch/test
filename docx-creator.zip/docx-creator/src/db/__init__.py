"""Database functionality for DOCX Creator.""" 
