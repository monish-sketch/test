"""Configuration constants for Database connections."""

from pathlib import Path

# Get the project root directory (assuming this file is in src/db/)
PROJECT_ROOT = Path(__file__).parent.parent.parent

# Default credentials file paths
DEFAULT_SUPABASE_CREDENTIALS_PATH = PROJECT_ROOT / "credentials" / "supabase.json"

# Database connection settings
DEFAULT_POOLER_REGION = "aws-1-ap-south-1"
DEFAULT_POOLER_PORT = "5432"
DEFAULT_DATABASE_NAME = "postgres"

# Connection string templates
SUPABASE_POOLER_TEMPLATE = (
    "postgresql://postgres.{project_id}:{supabase_key}@{pooler_host}:{port}/{db_name}"
)
SUPABASE_DIRECT_TEMPLATE = (
    "postgresql://postgres:{supabase_key}@db.{project_id}.supabase.co:{port}/{db_name}"
)

# Default connection type
DEFAULT_CONNECTION_TYPE = "pooler"  # or "direct"
