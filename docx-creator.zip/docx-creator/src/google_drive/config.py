"""Configuration constants for Google Drive Extractor."""

# Google Drive API scopes
SCOPES = [
    "https://www.googleapis.com/auth/drive.readonly",
    "https://www.googleapis.com/auth/spreadsheets.readonly",
]

# Supported file types
DATA_TYPES = {
    "spreadsheet": [".xlsx", ".xls", ".ods"],
    "document": [".docx", ".doc", ".odt"],
    "google_sheets": ["application/vnd.google-apps.spreadsheet"],
    "google_docs": ["application/vnd.google-apps.document"],
}

# MIME types for Google Workspace files
GOOGLE_MIME_TYPES = {
    "spreadsheet": "application/vnd.google-apps.spreadsheet",
    "document": "application/vnd.google-apps.document",
    "folder": "application/vnd.google-apps.folder",
}

# MIME types for Microsoft Office documents
OFFICE_MIME_TYPES = {
    "excel": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "word": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "word_footnotes": "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml",
}

# Default credentials file path
DEFAULT_CREDENTIALS_PATH = (
    r"C:\repositories\docx-creator\credentials\drive_service_account.json"
)

# Folder IDs
FIRESIDE_FOLDER_ID = "11TgHURtWPyPxHpDo7v69aTUdn57clKhO"
