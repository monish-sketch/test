"""Google Drive Extractor for reading files and converting to DataFrames."""

import os
import io
import zipfile
import xml.etree.ElementTree as ET
import pandas as pd
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload

from google_drive.config import SCOPES, DEFAULT_CREDENTIALS_PATH, GOOGLE_MIME_TYPES, OFFICE_MIME_TYPES
from google_drive.excel_util import read_excel_with_merged_cells
from utils.logging import get_logger

logger = get_logger(__name__)


class GoogleDriveExtractor:
    """Extract and convert Google Drive files to DataFrames."""

    def __init__(self, credentials_path=None):
        """Initialize Google Drive connection."""
        self.credentials_path = credentials_path or DEFAULT_CREDENTIALS_PATH
        self.service = None
        self.sheets_service = None
        self._authenticate()

    def _authenticate(self):
        """Authenticate using service account."""
        if not os.path.exists(self.credentials_path):
            raise FileNotFoundError(
                f"Service account file not found: {self.credentials_path}"
            )

        creds = service_account.Credentials.from_service_account_file(
            self.credentials_path, scopes=SCOPES
        )

        self.service = build("drive", "v3", credentials=creds)
        self.sheets_service = build("sheets", "v4", credentials=creds)

    def list_files(self, folder_id, recursive=False):
        """List files in a folder."""
        query = f"'{folder_id}' in parents"
        if not recursive:
            query += " and mimeType != 'application/vnd.google-apps.folder'"

        results = (
            self.service.files()
            .list(q=query, fields="nextPageToken, files(id, name, mimeType, parents)")
            .execute()
        )

        files = results.get("files", [])

        if recursive:
            folders = [
                f
                for f in files
                if f["mimeType"] == GOOGLE_MIME_TYPES.get("folder")
            ]
            for folder in folders:
                subfolder_files = self.list_files(folder["id"], recursive=True)
                files.extend(subfolder_files)

        return files

    def read_spreadsheet(self, file_id):
        """Read Google Sheets or Excel file and return DataFrames."""
        file_info = self.service.files().get(fileId=file_id).execute()
        mime_type = file_info.get("mimeType")

        if mime_type == GOOGLE_MIME_TYPES.get("spreadsheet"):
            logger.info(f"Reading Google Sheets file: {file_id}")
            return self._read_google_sheets(file_id)
        else:
            logger.info(f"Reading Excel file: {file_id}")
            return self._read_excel_file(file_id)

    def read_document(self, file_id):
        """Read Google Docs or Word document and extract tables."""
        file_info = self.service.files().get(fileId=file_id).execute()
        mime_type = file_info.get("mimeType")

        if mime_type == GOOGLE_MIME_TYPES.get("document"):
            logger.info(f"Reading Google Docs file: {file_id}")
            return self._read_google_docs(file_id)
        else:
            logger.info(f"Reading Word document: {file_id}")
            return self._read_word_document(file_id)

    def _read_google_sheets(self, file_id):
        """Read Google Sheets file with proper data extraction."""
        spreadsheet = (
            self.sheets_service.spreadsheets().get(spreadsheetId=file_id).execute()
        )

        sheets_data = {}

        for sheet in spreadsheet.get("sheets", []):
            sheet_name = sheet["properties"]["title"]
            range_name = f"{sheet_name}!A:Z"

            result = (
                self.sheets_service.spreadsheets()
                .values()
                .get(spreadsheetId=file_id, range=range_name)
                .execute()
            )

            values = result.get("values", [])
            if values:
                # Create raw DataFrame
                raw_df = pd.DataFrame(values[1:], columns=values[0])

                # Google Sheets doesn't have traditional merged cells like Excel
                # but we can detect empty cells that might be part of visual merges
                processed_df = self._detect_google_sheets_visual_merges(raw_df)

                sheets_data[sheet_name] = self._create_sheet_result(
                    raw_df, processed_df, []
                )

        return sheets_data

    def _create_sheet_result(self, raw_df, processed_df, merged_cells_info):
        """Create standardized sheet result structure."""
        return {
            'raw_data': raw_df,
            'processed_data': processed_df,
            'merged_cells': merged_cells_info
        }

    def _detect_google_sheets_visual_merges(self, df):
        """Detect potential visual merges in Google Sheets data."""
        # Google Sheets doesn't have true merged cells like Excel
        # This method preserves the original data structure
        return df.copy()

    def _download_file_content(self, file_id):
        """Download file content from Google Drive."""
        request = self.service.files().get_media(fileId=file_id)
        file_content = io.BytesIO()
        downloader = MediaIoBaseDownload(file_content, request)

        done = False
        while done is False:
            _status, done = downloader.next_chunk()

        file_content.seek(0)
        return file_content

    def _read_excel_file(self, file_id):
        """Read Excel file from Google Drive with merged cell detection."""
        file_content = self._download_file_content(file_id)

        try:
            return read_excel_with_merged_cells(file_content)
        except Exception as e:
            raise ValueError(f"Error reading Excel file: {e}") from e

    def _read_google_docs(self, file_id):
        """Read Google Docs file and extract tables."""
        request = self.service.files().export_media(
            fileId=file_id,
            mimeType=OFFICE_MIME_TYPES["word"],
        )
        file_content = io.BytesIO()
        downloader = MediaIoBaseDownload(file_content, request)

        done = False
        while done is False:
            _status, done = downloader.next_chunk()

        file_content.seek(0)
        return self._extract_tables_from_docx(file_content)

    def _read_word_document(self, file_id):
        """Read Word document from Google Drive."""
        file_content = self._download_file_content(file_id)
        return self._extract_tables_from_docx(file_content)

    def _extract_tables_from_docx(self, file_content):
        """Extract tables from DOCX file content (simple approach)."""
        tables_data = {}

        with zipfile.ZipFile(file_content, "r") as docx:
            document_xml = docx.read("word/document.xml")
            root = ET.fromstring(document_xml)

            table_count = 0
            for table in root.findall(
                ".//w:tbl",
                {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"},
            ):
                rows = []
                for row in table.findall(
                    ".//w:tr",
                    {
                        "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
                    },
                ):
                    cells = []
                    for cell in row.findall(
                        ".//w:tc",
                        {
                            "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
                        },
                    ):
                        cell_text = ""
                        for text_elem in cell.findall(
                            ".//w:t",
                            {
                                "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
                            },
                        ):
                            if text_elem.text:
                                cell_text += text_elem.text
                        cells.append(cell_text)
                    if cells:
                        rows.append(cells)

                if rows:
                    df = pd.DataFrame(rows[1:], columns=rows[0])
                    tables_data[f"table_{table_count}"] = df
                    table_count += 1

        return tables_data
