"""Excel utility functions for processing Excel files with merged cells."""

import io
from typing import Dict, List, Any

import pandas as pd
import openpyxl


def detect_excel_merged_cells(file_content: io.BytesIO, sheet_name: str) -> List[Dict[str, Any]]:
    """Detect merged cells in Excel file using openpyxl."""
    try:
        workbook = openpyxl.load_workbook(file_content)
        worksheet = workbook[sheet_name]

        merged_ranges = []
        for merged_range in worksheet.merged_cells.ranges:
            merged_ranges.append({
                'range': str(merged_range),
                'min_row': merged_range.min_row,
                'max_row': merged_range.max_row,
                'min_col': merged_range.min_col,
                'max_col': merged_range.max_col,
                'value': worksheet.cell(merged_range.min_row, merged_range.min_col).value
            })

        return merged_ranges
    except ImportError:
        # Fallback if openpyxl is not available
        return []
    except Exception as _e:
        return []


def process_excel_with_merged_cells(raw_df: pd.DataFrame, merged_cells_info: List[Dict[str, Any]]) -> pd.DataFrame:
    """Process Excel DataFrame with proper merged cell handling."""
    if not merged_cells_info:
        return raw_df

    # Create a copy to work with
    processed_df = raw_df.copy()

    for merged_info in merged_cells_info:
        # Convert to 0-based indexing
        start_row = merged_info['min_row'] - 1
        start_col = merged_info['min_col'] - 1
        end_row = merged_info['max_row'] - 1
        end_col = merged_info['max_col'] - 1

        # Fill the entire merged range
        processed_df.iloc[start_row:end_row+1, start_col:end_col+1] = processed_df.iloc[start_row, start_col]

    return processed_df


def read_excel_with_merged_cells(file_content: io.BytesIO):
    """Read Excel file and process merged cells for all sheets."""
    # Read raw data first
    raw_sheets_data = pd.read_excel(file_content, sheet_name=None, header=None)

    # Reset file pointer for merged cell detection
    file_content.seek(0)

    # Process each sheet
    result = {}
    for sheet_name, raw_df in raw_sheets_data.items():
        # Get merged cells information
        merged_info = detect_excel_merged_cells(file_content, sheet_name)

        # Process the data with merged cell handling
        processed_df = process_excel_with_merged_cells(raw_df, merged_info)

        result[sheet_name] = {
            'raw_data': raw_df,
            'processed_data': processed_df,
            'merged_cells': merged_info
        }

        # Reset file pointer for next sheet
        file_content.seek(0)

    return result
